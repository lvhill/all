
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>retrieveMemberChangeHisResponse complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="retrieveMemberChangeHisResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="memberChangeHisData" type="{http://member.facade.service.ebiz.amway.com/}memberChangeHisData" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveMemberChangeHisResponse", propOrder = {
    "memberChangeHisData"
})
public class RetrieveMemberChangeHisResponse {

    protected List<MemberChangeHisData> memberChangeHisData;

    /**
     * Gets the value of the memberChangeHisData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the memberChangeHisData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMemberChangeHisData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MemberChangeHisData }
     * 
     * 
     */
    public List<MemberChangeHisData> getMemberChangeHisData() {
        if (memberChangeHisData == null) {
            memberChangeHisData = new ArrayList<MemberChangeHisData>();
        }
        return this.memberChangeHisData;
    }

}
