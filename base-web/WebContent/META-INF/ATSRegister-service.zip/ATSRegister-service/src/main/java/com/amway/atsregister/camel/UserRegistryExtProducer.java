package com.amway.atsregister.camel;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.builder.ExchangeBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amway.atsregister.aftersale.dto.UserRegistryExt;

/**
 * 将售后服务登记信息发送给jms
 * 
 * @author xl,xu
 * 
 */
@Component
public class UserRegistryExtProducer {

	@Autowired
	private ExchangeBuilder builder;

	/**
	 * 将售后服务登记信息发送给jms
	 * 
	 * @param result
	 */
	public void send(List<UserRegistryExt> userRegistryExts) throws Exception {
		try {
			if (null != userRegistryExts) {
				Exchange exchng = builder.build();
				exchng.getIn().setBody(userRegistryExts);
				exchng.getContext().createProducerTemplate().send("direct:userRegistryExt", exchng);
			}
		} catch (Exception e) {
			throw e;
		}

	}
}
