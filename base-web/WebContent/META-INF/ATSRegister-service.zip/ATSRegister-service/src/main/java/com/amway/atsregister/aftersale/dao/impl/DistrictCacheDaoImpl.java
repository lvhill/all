package com.amway.atsregister.aftersale.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.amway.atsregister.aftersale.dao.DistrictCacheDao;
import com.amway.atsregister.aftersale.dto.DistrictGB;
import com.amway.atsregister.aftersale.vo.District;

@Repository("districtCacheDao")
public class DistrictCacheDaoImpl implements DistrictCacheDao {

	@Autowired
	protected MongoTemplate mongoTemplate;

	private Map<String, List<District>> districtCacheMap = new HashMap<String, List<District>>();
	private Date cacheTime = new Date();
	private long cacheTimeInterval = 1000 * 60 * 60 * 3; // 缓存时间3小时

	private String provMapKey = "_ZGSF_";// 省的map的key

	private void reload() {
		districtCacheMap.clear();
		//
		List<District> provList = getProvListByDb();
		districtCacheMap.put(provMapKey, provList);
		//
		for (District provDistrict : provList) {
			String provCode = provDistrict.getDistrictCode();
			List<District> cityList = getCitysByProvinceByDb(provCode);
			districtCacheMap.put(provCode, cityList);
			//
			for (District cityDistrict : cityList) {
				String cityCode = cityDistrict.getDistrictCode();
				List<District> townList = getTownByCityByDb(cityCode);
				districtCacheMap.put(cityCode, townList);
			}
		}
		//
		cacheTime = new Date();
	}

	/**
	 * 如果过期了就重新加载
	 */
	private void reloadIfExpire() {
		long intervalTime = new Date().getTime() - cacheTime.getTime();
		if (districtCacheMap.size() == 0 || intervalTime > cacheTimeInterval) {
			reload();
		}
	}

	public List<District> getProvList() {
		reloadIfExpire();
		return districtCacheMap.get(provMapKey);
	}

	public List<District> getCitysByProvince(String provCode) {
		reloadIfExpire();
		return districtCacheMap.get(provCode);
	}

	public List<District> getTownByCity(String cityCode) {
		reloadIfExpire();
		return districtCacheMap.get(cityCode);
	}

	private List<District> getProvListByDb() {
		// 执行mongodb查询:db.getCollection('districtGB').find({"district_type":"1"})
		Criteria criatira = new Criteria();
		criatira.andOperator(Criteria.where("district_type").is("1"));
		List<DistrictGB> listGB = mongoTemplate.find(new Query(criatira), DistrictGB.class);
		List<District> list = new ArrayList<District>();
		for (DistrictGB gb : listGB) {
			District dist = new District();
			dist.setDistrictName(gb.getDistrict_name());
			dist.setDistrictCode(gb.getDistrict_code());
			list.add(dist);
		}
		return list;
	}

	private List<District> getCitysByProvinceByDb(String provCode) {
		// 执行mongodb查询(比如查询广东省的市列表):db.getCollection('districtGB').find({"district_type":"2",'par_district_code':'GD'})
		Criteria criatira = new Criteria();
		criatira.andOperator(Criteria.where("district_type").is("2").and("par_district_code").is(provCode));
		List<DistrictGB> listGB = mongoTemplate.find(new Query(criatira), DistrictGB.class);
		List<District> list = new ArrayList<District>();
		for (DistrictGB gb : listGB) {
			District dist = new District();
			dist.setDistrictName(gb.getDistrict_name());
			dist.setDistrictCode(gb.getDistrict_code());
			list.add(dist);
		}
		return list;
	}

	private List<District> getTownByCityByDb(String cityCode) {
		// 执行mongodb查询(比如查询广州的区列表):db.getCollection('districtGB').find({"district_type":"4",'par_district_code':'GD_GZ'})
		Criteria criatira = new Criteria();
		criatira.andOperator(Criteria.where("district_type").is("4").and("par_district_code").is(cityCode));
		List<DistrictGB> listGB = mongoTemplate.find(new Query(criatira), DistrictGB.class);
		List<District> list = new ArrayList<District>();
		for (DistrictGB gb : listGB) {
			District dist = new District();
			dist.setDistrictName(gb.getDistrict_name());
			dist.setDistrictCode(gb.getDistrict_code());
			list.add(dist);
		}
		return list;
	}

	public void setCacheInterval(long cacheTimeInterval) {
		this.cacheTimeInterval = cacheTimeInterval;
	}

	public long getCacheInterval() {
		return cacheTimeInterval;
	}

}
