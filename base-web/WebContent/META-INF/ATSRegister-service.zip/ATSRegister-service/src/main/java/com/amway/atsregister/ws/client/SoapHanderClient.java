package com.amway.atsregister.ws.client;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.amway.atsregister.ws.client.dto.memberinfosrv.RetrieveMember;
import com.amway.atsregister.ws.client.dto.memberinfosrv.RetrieveMemberResponse;
import com.amway.atsregister.ws.client.soap.SoaJsonConfig;
import com.amway.atsregister.ws.client.soap.SoapClient;
import com.amway.atsregister.ws.client.soap.SoapEntity;

import net.sf.json.JSONObject;

public class SoapHanderClient {
	private static final Logger log = LogManager.getLogger(SoapHanderClient.class);

	/**
	 * 调用易联网 retrieveDistributorInfo接口判断安利号是否存在
	 * 
	 * @param adano 安利号
	 * @return 存在true, 否则false
	 */
	public static boolean retrieveMember(String adano) {
		JSONObject json = SoaJsonConfig.getJsonFormatbymethod("ebiz_member_info");
		String wsdlUrl = json.getString("soaURL");
		String osbappid = json.getString("osbappid");
		String osbappkey = json.getString("osbappkey");
		//
		SoapEntity<Header, RetrieveMember> request = new SoapEntity<Header, RetrieveMember>(
				Header.class, RetrieveMember.class);
		Header head = new Header();
		head.setOsbappid(osbappid);
		head.setOsbappkey(osbappkey);
		request.setHead(head);
		//
		RetrieveMember retrieveMember = new RetrieveMember();
		//
		Long ada = Long.valueOf(adano);
		retrieveMember.setArg0(ada);
		//
		request.setBody(retrieveMember);
		//
		SoapEntity<Header, RetrieveMemberResponse> response = new SoapEntity<Header, RetrieveMemberResponse>(
				Header.class, RetrieveMemberResponse.class);
		try {
			SoapClient.execute(wsdlUrl, request, response);
			String resultCode = response.getBody().getMemberinfo().getReturnCode();
			if ("0".equals(resultCode)) {
				return true;
			}
		} catch (Exception e) {
			log.error("error.soa.common, function: retrieveDistributorInfo, distributorNumber:" + adano, e);
			return false;
		}
		return false;
	}

	public static void main(String args[]) {
		boolean s = SoapHanderClient.retrieveMember("34888");
		System.out.println(s);
	}
}
