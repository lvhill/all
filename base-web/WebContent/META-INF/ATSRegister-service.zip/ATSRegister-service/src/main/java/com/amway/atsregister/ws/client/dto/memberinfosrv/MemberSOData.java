
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>memberSOData complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="memberSOData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://member.facade.service.ebiz.amway.com/}inquiryObject">
 *       &lt;sequence>
 *         &lt;element name="address" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="beginBirthday" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="cname" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="code" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="curPage" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="endBirthday" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="idCardNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="pageSize" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="phoneM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="phoneS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "memberSOData", propOrder = {
    "address",
    "beginBirthday",
    "cname",
    "code",
    "curPage",
    "endBirthday",
    "idCardNo",
    "pageSize",
    "phoneM",
    "phoneS"
})
public class MemberSOData
    extends InquiryObject
{

    protected String address;
    protected int beginBirthday;
    protected String cname;
    protected String code;
    protected int curPage;
    protected int endBirthday;
    protected String idCardNo;
    protected int pageSize;
    protected String phoneM;
    protected String phoneS;

    /**
     * 获取address属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress() {
        return address;
    }

    /**
     * 设置address属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress(String value) {
        this.address = value;
    }

    /**
     * 获取beginBirthday属性的值。
     * 
     */
    public int getBeginBirthday() {
        return beginBirthday;
    }

    /**
     * 设置beginBirthday属性的值。
     * 
     */
    public void setBeginBirthday(int value) {
        this.beginBirthday = value;
    }

    /**
     * 获取cname属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCname() {
        return cname;
    }

    /**
     * 设置cname属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCname(String value) {
        this.cname = value;
    }

    /**
     * 获取code属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCode() {
        return code;
    }

    /**
     * 设置code属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    /**
     * 获取curPage属性的值。
     * 
     */
    public int getCurPage() {
        return curPage;
    }

    /**
     * 设置curPage属性的值。
     * 
     */
    public void setCurPage(int value) {
        this.curPage = value;
    }

    /**
     * 获取endBirthday属性的值。
     * 
     */
    public int getEndBirthday() {
        return endBirthday;
    }

    /**
     * 设置endBirthday属性的值。
     * 
     */
    public void setEndBirthday(int value) {
        this.endBirthday = value;
    }

    /**
     * 获取idCardNo属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdCardNo() {
        return idCardNo;
    }

    /**
     * 设置idCardNo属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdCardNo(String value) {
        this.idCardNo = value;
    }

    /**
     * 获取pageSize属性的值。
     * 
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     * 设置pageSize属性的值。
     * 
     */
    public void setPageSize(int value) {
        this.pageSize = value;
    }

    /**
     * 获取phoneM属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhoneM() {
        return phoneM;
    }

    /**
     * 设置phoneM属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhoneM(String value) {
        this.phoneM = value;
    }

    /**
     * 获取phoneS属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhoneS() {
        return phoneS;
    }

    /**
     * 设置phoneS属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhoneS(String value) {
        this.phoneS = value;
    }

}
