package com.amway.atsregister.common.util;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 数据字典
 * 
 * @author xl,xu
 * 
 */
@Component
public class Constants {
    private Logger log = LoggerFactory.getLogger(Constants.class);
    @Value("${vendor.url}")
    private String url;

    public static String VENDOR_URL;// 海尔接口地址
    public static final String REPAIR_ORDER = "/RepairOrder";// 维修单
    public static final String INSTALL_ORDER = "/InstallOrder";// 安装单

    public static final String INSTALL_RESULT = "/InstallResult";// 安装结果
    public static final String REPAIR_RESULT = "/RepairResult";// 维修结果
    public static final int OSB_TIME_OUT = 20;// 响应时间
    public static final String ENCODING = "utf-8";// 编码

    public static final String ACCESS_SUCCESS = "200";// 访问成功编码

    public static final String RESENDCANCELORDERQUARTZ = "reSendCancelOrderQuartz";// 重发注销订单job
    public static final String RESENDINSTALLORDERQUARTZ = "reSendInstallOrderQuartz";// 重发安装单job
    public static final String RESENDINSTALLRESULTQUARTZ = "reSendInstallResultQuartz";// 重发安装结果job
    public static final String RESENDREPAIRORDERQUARTZ = "reSendRepairOrderQuartz";// 重发维修单job
    public static final String RESENDREPAIRRESULTQUARTZ = "reSendRepairResultQuartz";// 重发
                                                                                     // 维修结果job
    public static final String USERREGISTREXPORTQUARTZ = "userRegistrExportQuartz";// 定时生成用户登记信息job

    @PostConstruct
    public void init() {
        if (null != url) {
            VENDOR_URL = url;
        } else {
            log.warn("海尔接口URL初始化失败!");
        }
    }
}
