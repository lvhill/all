package com.amway.atsregister.system;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.Topic;
import javax.naming.NamingException;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.ExchangeBuilder;
import org.apache.camel.component.jms.JmsComponent;
import org.apache.camel.model.DataFormatDefinition;
import org.apache.camel.spring.boot.CamelContextConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.support.destination.CachingDestinationResolver;
import org.springframework.jms.support.destination.DestinationResolutionException;
import org.springframework.jms.support.destination.DestinationResolver;
import org.springframework.jms.support.destination.DynamicDestinationResolver;
import org.springframework.jndi.JndiLocatorSupport;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.jndi.JndiTemplate;
import org.springframework.util.Assert;

/**
 * camel配置类 Created by abc123 on 17/3/21.
 */
@Configuration
public class CamelConfiguration {

	@Autowired
	private JndiTemplate jndiTemplate;

	@Autowired
	private JndiObjectFactoryBean jndiObjectFactoryBean;

	@Bean
	public ExchangeBuilder getExchangeBuilder(CamelContext camelContext) {
		ExchangeBuilder exchangeBuilder = new ExchangeBuilder(camelContext);
		return exchangeBuilder;
	}

	@Bean
	CamelContextConfiguration contextConfiguration() {
		return new CamelContextConfiguration() {
			@Override
			public void beforeApplicationStart(CamelContext context) {
				Map<String, DataFormatDefinition> var1 = new HashMap<>();
				context.setDataFormats(var1);
				JmsComponent jmsComponent = new JmsComponent();
				jmsComponent.setConnectionFactory((ConnectionFactory) jndiObjectFactoryBean.getObject());
				jmsComponent.setDestinationResolver(new SelfJndiDestinationResolver());
				context.addComponent("jms", jmsComponent);
			}

			@Override
			public void afterApplicationStart(CamelContext camelContext) {

			}
		};
	}

	class SelfJndiDestinationResolver extends JndiLocatorSupport implements CachingDestinationResolver {
		private boolean cache = true;
		private boolean fallbackToDynamicDestination = false;
		private DestinationResolver dynamicDestinationResolver = new DynamicDestinationResolver();
		private final Map<String, Destination> destinationCache = new ConcurrentHashMap<String, Destination>(16);

		public SelfJndiDestinationResolver() {
		}

		public void setCache(boolean cache) {
			this.cache = cache;
		}

		public void setFallbackToDynamicDestination(boolean fallbackToDynamicDestination) {
			this.fallbackToDynamicDestination = fallbackToDynamicDestination;
		}

		public void setDynamicDestinationResolver(DestinationResolver dynamicDestinationResolver) {
			this.dynamicDestinationResolver = dynamicDestinationResolver;
		}

		@Override
		public Destination resolveDestinationName(Session session, String destinationName, boolean pubSubDomain)
				throws JMSException {
			Assert.notNull(destinationName, "Destination name must not be null");
			Destination dest = (Destination) this.destinationCache.get(destinationName);
			if (dest != null) {
				this.validateDestination(dest, destinationName, pubSubDomain);
			} else {
				try {
					dest = (Destination) jndiTemplate.lookup(destinationName, Destination.class);
					this.validateDestination(dest, destinationName, pubSubDomain);
				} catch (NamingException var6) {
					if (this.logger.isDebugEnabled()) {
						this.logger.debug("Destination [" + destinationName + "] not found in JNDI", var6);
					}

					if (!this.fallbackToDynamicDestination) {
						throw new DestinationResolutionException(
								"Destination [" + destinationName + "] not found in JNDI", var6);
					}

					dest = this.dynamicDestinationResolver.resolveDestinationName(session, destinationName,
							pubSubDomain);
				}

				if (this.cache) {
					this.destinationCache.put(destinationName, dest);
				}
			}

			return dest;
		}

		protected void validateDestination(Destination destination, String destinationName, boolean pubSubDomain) {
			Class<?> targetClass = Queue.class;
			if (pubSubDomain) {
				targetClass = Topic.class;
			}

			if (!targetClass.isInstance(destination)) {
				throw new DestinationResolutionException("Destination [" + destinationName
						+ "] is not of expected type [" + targetClass.getName() + "]");
			}
		}

		public void removeFromCache(String destinationName) {
			this.destinationCache.remove(destinationName);
		}

		public void clearCache() {
			this.destinationCache.clear();
		}

	}
}
