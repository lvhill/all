package com.amway.atsregister.ws.client.soap;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import net.sf.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SoaJsonConfig
{
	private static final Logger LOGGER = LoggerFactory.getLogger(SoaJsonConfig.class);

	private static String soa_config_service = "soa_config_service";

	private static SoaJsonConfig soaJsonConfig;

	private static Properties jsonProperties = null;

	private static Properties soa_config_properties = null;

	static
	{
		setSOAPathconfig();
	}

	public static Properties getSoa_config_properties()
	{
		return soa_config_properties;
	}

	public static void setSoa_config_properties(Properties soa_config_properties)
	{
		SoaJsonConfig.soa_config_properties = soa_config_properties;
	}

	public static void setSOAPathconfig()
	{
		if (jsonProperties == null)
		{
			InputStream inputStream = null;

			inputStream = SoaJsonConfig.class.getClassLoader().getResourceAsStream("json.properties");
			jsonProperties = new Properties();
			try
			{
				jsonProperties.load(inputStream);
			} catch (IOException e)
			{
				LOGGER.error("Unnable to load 'json.properties' file", e);
				System.exit(1);
			} finally
			{
				if (inputStream != null)
				{
					try
					{
						inputStream.close();
					} catch (IOException e)
					{
						e.printStackTrace();// no need to log
					}
				}
			}
		}

	}

	public static Properties getSOAProperties()
	{

		if (soa_config_properties != null)
		{
			return soa_config_properties;
		} else
		{
			InputStream resourceAsStream = null;
			String propertyFilePath = getJsonProperties().getProperty(soa_config_service);
			try
			{
				resourceAsStream = new FileInputStream(propertyFilePath);

				soa_config_properties = new Properties();
				soa_config_properties.load(resourceAsStream);
			} catch (IOException e)
			{
				LOGGER.error("Could not load soa_config properties  file from '" + propertyFilePath
						+ "', system will be shutdown.", e);
				System.exit(1);
			} finally
			{
				if (resourceAsStream != null)
				{
					try
					{
						resourceAsStream.close();
					} catch (IOException e)
					{
						e.printStackTrace();// no need to log
					}
				}
			}

			return soa_config_properties;
		}
	}

	public static SoaJsonConfig getInstance()
	{
		if (soaJsonConfig == null)
		{
			soaJsonConfig = new SoaJsonConfig();
		}
		return soaJsonConfig;
	}

	public String getPathValue(String key)
	{
		if (jsonProperties == null)
		{
			setSOAPathconfig();
		}
		return jsonProperties.getProperty(key);
	}

	public static Properties getJsonProperties()
	{
		if (jsonProperties == null)
		{
			setSOAPathconfig();
		}
		return jsonProperties;
	}

	public static void setJsonProperties(Properties jsonProperties)
	{
		SoaJsonConfig.jsonProperties = jsonProperties;
	}

	public String readFile(String path) throws Exception
	{
		BufferedReader input = null;
		InputStream fis = null;
		try
		{
			fis = new FileInputStream(path);
			input = new BufferedReader(new InputStreamReader(fis, "utf-8")); // 读取流
		} catch (Exception e)
		{
			// 如果指定路径找不到文件，继续找项目工程里的文件。
			String filepath = path.substring(path.lastIndexOf(File.separator) + 1);
			fis = this.getClass().getClassLoader().getResourceAsStream(filepath);
			input = new BufferedReader(new InputStreamReader(fis, "utf-8")); // 读取流

		}
		StringBuffer body = new StringBuffer();
		String str = null;
		while ((str = input.readLine()) != null)
		{ // 判断是否读到了最后一行
			body.append(str);
		}
		if (fis != null)
		{
			fis.close();
		}
		if (input != null)
		{
			input.close();
		}
		return body.toString();
	}

	// 读取request xml 配置的 json格式,之后的逻辑是先读取 redis的配置，再读取文件的配置

	public static JSONObject getJsonformat(String configfilepath) throws Exception
	{
		return JSONObject.fromObject(getInstance().readFile(configfilepath));

	}

	public static JSONObject getJsonFormatbymethod(String serviceProject)
	{
		String xmlns_name = getSOAProperties().getProperty(serviceProject + "_" + "xmlns_name");
		String xmlns_link = getSOAProperties().getProperty(serviceProject + "_" + "xmlns_link");
		String osbappid = getSOAProperties().getProperty(serviceProject + "_" + "osbappid");
		String osbappkey = getSOAProperties().getProperty(serviceProject + "_" + "osbappkey");
		String soaURL = getSOAProperties().getProperty(serviceProject + "_" + "soaURL");
		String currencyCode = getSOAProperties().getProperty(serviceProject + "_" + "currencyCode");
		String locale = getSOAProperties().getProperty(serviceProject + "_" + "locale");
		String regionCode = getSOAProperties().getProperty(serviceProject + "_" + "regionCode");
		JSONObject jobj = new JSONObject();
		try
		{
			jobj.put("xmlns_name", xmlns_name);
			jobj.put("xmlns_link", xmlns_link);
			jobj.put("osbappid", osbappid);
			jobj.put("osbappkey", osbappkey);
			jobj.put("soaURL", soaURL);
			jobj.put("currencyCode", currencyCode);
			jobj.put("locale", locale);
			jobj.put("regionCode", regionCode);
		} catch (Exception e)
		{
			LOGGER.error("Unnable to parse config file path to json format by 'class_config'", e);
		}
		return jobj;
	}
}
