
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>reActiveMemberForPosRenewalResponse complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="reActiveMemberForPosRenewalResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="returnData" type="{http://member.facade.service.ebiz.amway.com/}inquiryObject" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "reActiveMemberForPosRenewalResponse", propOrder = {
    "returnData"
})
public class ReActiveMemberForPosRenewalResponse {

    protected InquiryObject returnData;

    /**
     * 获取returnData属性的值。
     * 
     * @return
     *     possible object is
     *     {@link InquiryObject }
     *     
     */
    public InquiryObject getReturnData() {
        return returnData;
    }

    /**
     * 设置returnData属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link InquiryObject }
     *     
     */
    public void setReturnData(InquiryObject value) {
        this.returnData = value;
    }

}
