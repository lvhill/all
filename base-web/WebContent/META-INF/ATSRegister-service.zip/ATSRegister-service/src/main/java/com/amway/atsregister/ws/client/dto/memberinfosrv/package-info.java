@javax.xml.bind.annotation.XmlSchema(namespace = "http://member.facade.service.ebiz.amway.com/")
package com.amway.atsregister.ws.client.dto.memberinfosrv;
