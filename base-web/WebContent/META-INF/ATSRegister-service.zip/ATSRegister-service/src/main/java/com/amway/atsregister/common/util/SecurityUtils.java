package com.amway.atsregister.common.util;

import javax.annotation.PostConstruct;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * 安全认证工具类
 * 
 * @author xl,xu
 * 
 */
@Component
public class SecurityUtils {
    @Value("${security.salt}")
    private String salt;
    private static String SALT;
    private static Logger log = LoggerFactory.getLogger(SecurityUtils.class);

    @PostConstruct
    public void init() {
        if (null != salt) {
            SALT = salt;
        } else {
            log.warn("安全信息初始化失败!");
        }
    }

    /**
     * 校验接口调用者是否有权限
     * 
     * @param randkey
     * @param authcode
     * @return
     */
    public static boolean isSecurity(String randkey, String authcode) {
        if (StringUtils.isEmpty(randkey) || StringUtils.isEmpty(authcode)) {
            log.info("身份校验不通过,密文错误,参数为空!");
            return false;
        } else {
            try {
                String miStr = DigestUtils.md5Hex(randkey + SALT);
                // 比较时忽略大小写
                if ((authcode.equalsIgnoreCase(miStr))) {
                    return true;
                } else {
                    log.info("身份校验不通过,密文错误,randkey=" + randkey + ",authcode=" + authcode + ",miStr=" + miStr);
                    return false;
                }
            } catch (Exception e) {
                log.error("加密失败:" + e.getMessage());
                return false;
            }

        }
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

    public static String getSALT() {
        return SALT;
    }

    public static void setSALT(String sALT) {
        SALT = sALT;
    }

}
