
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>member complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="member">
 *   &lt;complexContent>
 *     &lt;extension base="{http://member.facade.service.ebiz.amway.com/}inquiryObject">
 *       &lt;sequence>
 *         &lt;element name="addresses" type="{http://member.facade.service.ebiz.amway.com/}address" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="affiliatedWarehouse" type="{http://member.facade.service.ebiz.amway.com/}warehouse" minOccurs="0"/>
 *         &lt;element name="agents" type="{http://member.facade.service.ebiz.amway.com/}agent" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="bankAccs" type="{http://member.facade.service.ebiz.amway.com/}bankAcc" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="directDists" type="{http://member.facade.service.ebiz.amway.com/}directDistLicence" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="emails" type="{http://member.facade.service.ebiz.amway.com/}email" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="memberInfo" type="{http://member.facade.service.ebiz.amway.com/}memberInfo" minOccurs="0"/>
 *         &lt;element name="mstPerson" type="{http://member.facade.service.ebiz.amway.com/}person" minOccurs="0"/>
 *         &lt;element name="phones" type="{http://member.facade.service.ebiz.amway.com/}phone" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="signupWarehouse" type="{http://member.facade.service.ebiz.amway.com/}warehouse" minOccurs="0"/>
 *         &lt;element name="spousePerson" type="{http://member.facade.service.ebiz.amway.com/}person" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "member", propOrder = {
    "addresses",
    "affiliatedWarehouse",
    "agents",
    "bankAccs",
    "directDists",
    "emails",
    "memberInfo",
    "mstPerson",
    "phones",
    "signupWarehouse",
    "spousePerson"
})
public class Member
    extends InquiryObject
{

    @XmlElement(nillable = true)
    protected List<Address> addresses;
    protected Warehouse affiliatedWarehouse;
    @XmlElement(nillable = true)
    protected List<Agent> agents;
    @XmlElement(nillable = true)
    protected List<BankAcc> bankAccs;
    @XmlElement(nillable = true)
    protected List<DirectDistLicence> directDists;
    @XmlElement(nillable = true)
    protected List<Email> emails;
    protected MemberInfo memberInfo;
    protected Person mstPerson;
    @XmlElement(nillable = true)
    protected List<Phone> phones;
    protected Warehouse signupWarehouse;
    protected Person spousePerson;

    /**
     * Gets the value of the addresses property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addresses property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddresses().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Address }
     * 
     * 
     */
    public List<Address> getAddresses() {
        if (addresses == null) {
            addresses = new ArrayList<Address>();
        }
        return this.addresses;
    }

    /**
     * 获取affiliatedWarehouse属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Warehouse }
     *     
     */
    public Warehouse getAffiliatedWarehouse() {
        return affiliatedWarehouse;
    }

    /**
     * 设置affiliatedWarehouse属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Warehouse }
     *     
     */
    public void setAffiliatedWarehouse(Warehouse value) {
        this.affiliatedWarehouse = value;
    }

    /**
     * Gets the value of the agents property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the agents property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAgents().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Agent }
     * 
     * 
     */
    public List<Agent> getAgents() {
        if (agents == null) {
            agents = new ArrayList<Agent>();
        }
        return this.agents;
    }

    /**
     * Gets the value of the bankAccs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bankAccs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBankAccs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BankAcc }
     * 
     * 
     */
    public List<BankAcc> getBankAccs() {
        if (bankAccs == null) {
            bankAccs = new ArrayList<BankAcc>();
        }
        return this.bankAccs;
    }

    /**
     * Gets the value of the directDists property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the directDists property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDirectDists().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DirectDistLicence }
     * 
     * 
     */
    public List<DirectDistLicence> getDirectDists() {
        if (directDists == null) {
            directDists = new ArrayList<DirectDistLicence>();
        }
        return this.directDists;
    }

    /**
     * Gets the value of the emails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the emails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEmails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Email }
     * 
     * 
     */
    public List<Email> getEmails() {
        if (emails == null) {
            emails = new ArrayList<Email>();
        }
        return this.emails;
    }

    /**
     * 获取memberInfo属性的值。
     * 
     * @return
     *     possible object is
     *     {@link MemberInfo }
     *     
     */
    public MemberInfo getMemberInfo() {
        return memberInfo;
    }

    /**
     * 设置memberInfo属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link MemberInfo }
     *     
     */
    public void setMemberInfo(MemberInfo value) {
        this.memberInfo = value;
    }

    /**
     * 获取mstPerson属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Person }
     *     
     */
    public Person getMstPerson() {
        return mstPerson;
    }

    /**
     * 设置mstPerson属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Person }
     *     
     */
    public void setMstPerson(Person value) {
        this.mstPerson = value;
    }

    /**
     * Gets the value of the phones property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the phones property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPhones().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Phone }
     * 
     * 
     */
    public List<Phone> getPhones() {
        if (phones == null) {
            phones = new ArrayList<Phone>();
        }
        return this.phones;
    }

    /**
     * 获取signupWarehouse属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Warehouse }
     *     
     */
    public Warehouse getSignupWarehouse() {
        return signupWarehouse;
    }

    /**
     * 设置signupWarehouse属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Warehouse }
     *     
     */
    public void setSignupWarehouse(Warehouse value) {
        this.signupWarehouse = value;
    }

    /**
     * 获取spousePerson属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Person }
     *     
     */
    public Person getSpousePerson() {
        return spousePerson;
    }

    /**
     * 设置spousePerson属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Person }
     *     
     */
    public void setSpousePerson(Person value) {
        this.spousePerson = value;
    }

}
