package com.amway.atsregister.aftersale.vo;

/**
 * 类功能描述：地区对象
 * 
 * @author ligaofu
 */
public class District implements java.io.Serializable {
	private static final long serialVersionUID = -1712380597860635109L;

	/** 地区编码 */
	private String districtCode;
	/** 地区名称 */
	private String districtName;

	public String getDistrictCode() {
		return districtCode;
	}

	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}

	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

}
