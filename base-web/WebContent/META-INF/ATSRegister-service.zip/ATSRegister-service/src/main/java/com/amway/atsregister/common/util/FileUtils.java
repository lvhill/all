package com.amway.atsregister.common.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 文件工具类
 * 
 * @author xl,xu
 * 
 */
@Component
public class FileUtils {
    @Value("${gbLogFilePath}")
    private String filePath;

    @PostConstruct
    public void init() {
        File file = new File(filePath);
        if (!file.exists()) {
            file.mkdirs();
        }
    }

    /**
     * 向文件追加内容,文件名为当前时间截取年月日
     * 
     * @param content
     */
    public void append(String content) throws IOException {
        FileWriter fw = null;
        try {
            fw = new FileWriter(getFileName(), true);
            fw.write(content + "\r\n");
        } catch (IOException e) {
            throw e;
        } finally {
            if (null != fw) {
                try {
                    fw.close();
                } catch (IOException e) {
                    throw e;
                }
            }
        }

    }

    /**
     * 获取当前时间文件名
     * 
     * @return
     */
    private String getFileName() {
        Date date = new Date();
        String fileName = SafeDateFormat.format(date);
        return filePath + File.separator + fileName + ".log";
    }

}
