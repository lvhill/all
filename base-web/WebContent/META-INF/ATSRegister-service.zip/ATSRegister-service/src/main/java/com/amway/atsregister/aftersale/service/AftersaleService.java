package com.amway.atsregister.aftersale.service;

import java.util.List;

import com.amway.atsregister.aftersale.vo.District;
import com.amway.atsregister.aftersale.vo.UserRegistryVO;

public interface AftersaleService {

	/**
	 * 保存售后服务登记信息
	 * @param serRegistryVO
	 */
	public void save(UserRegistryVO userRegistryVO) throws Exception;
	
	/**
	 * 获取所有省
	 * @return
	 */
	public List<District> getProvList();
	
	/**
	 * 通过指定省获取所有市
	 * @return
	 */
	public List<District> getCitysByProvince(String province);
	
	/**
	 * 通过指定市获取所有县区
	 * @return
	 */
	public List<District> getTownByCity(String cityName);
}
