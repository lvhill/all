package com.amway.atsregister.common.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.amway.atsregister.common.dao.BaseDao;
import com.amway.atsregister.common.service.BaseService;

@Service("baseService")
public class BaseServiceImpl<T> implements BaseService<T> {

    private BaseDao<T> baseDao;

    public BaseDao<T> getBaseDao() {
        return baseDao;
    }

    @Autowired
    public void setBaseDao(BaseDao<T> baseDao) {
        this.baseDao = baseDao;
    }

    @Override
    public void save(T t) {
        baseDao.save(t);
    }

    @Override
    public T findObjectById(String id) {
        return baseDao.findObjectById(id);
    }

    @Override
    public void update(Query q, Update u) {
        baseDao.update(q, u);

    }

    @Override
    public void remove(Query q) {
        baseDao.remove(q);

    }

    @Override
    public void insert(T t) {
        baseDao.insert(t);
    }

    @Override
    public boolean isExist(String id) {
        return baseDao.isExist(id);
    }

}
