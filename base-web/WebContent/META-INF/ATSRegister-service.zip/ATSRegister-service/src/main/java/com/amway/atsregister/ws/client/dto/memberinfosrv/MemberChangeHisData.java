
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>memberChangeHisData complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="memberChangeHisData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://member.facade.service.ebiz.amway.com/}inquiryObject">
 *       &lt;sequence>
 *         &lt;element name="ada" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="auditReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="auditReasonDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="auditTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dbBatch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dbDate" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="dbProcessDate" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="dbProcessUser" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dbSequence" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="hid" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="transferDate" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "memberChangeHisData", propOrder = {
    "ada",
    "auditReasonCode",
    "auditReasonDescription",
    "auditTypeCode",
    "dbBatch",
    "dbDate",
    "dbProcessDate",
    "dbProcessUser",
    "dbSequence",
    "hid",
    "transferDate"
})
public class MemberChangeHisData
    extends InquiryObject
{

    protected Long ada;
    protected String auditReasonCode;
    protected String auditReasonDescription;
    protected String auditTypeCode;
    protected String dbBatch;
    protected int dbDate;
    protected long dbProcessDate;
    protected String dbProcessUser;
    protected String dbSequence;
    protected Long hid;
    protected long transferDate;

    /**
     * 获取ada属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAda() {
        return ada;
    }

    /**
     * 设置ada属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAda(Long value) {
        this.ada = value;
    }

    /**
     * 获取auditReasonCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuditReasonCode() {
        return auditReasonCode;
    }

    /**
     * 设置auditReasonCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuditReasonCode(String value) {
        this.auditReasonCode = value;
    }

    /**
     * 获取auditReasonDescription属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuditReasonDescription() {
        return auditReasonDescription;
    }

    /**
     * 设置auditReasonDescription属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuditReasonDescription(String value) {
        this.auditReasonDescription = value;
    }

    /**
     * 获取auditTypeCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuditTypeCode() {
        return auditTypeCode;
    }

    /**
     * 设置auditTypeCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuditTypeCode(String value) {
        this.auditTypeCode = value;
    }

    /**
     * 获取dbBatch属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbBatch() {
        return dbBatch;
    }

    /**
     * 设置dbBatch属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbBatch(String value) {
        this.dbBatch = value;
    }

    /**
     * 获取dbDate属性的值。
     * 
     */
    public int getDbDate() {
        return dbDate;
    }

    /**
     * 设置dbDate属性的值。
     * 
     */
    public void setDbDate(int value) {
        this.dbDate = value;
    }

    /**
     * 获取dbProcessDate属性的值。
     * 
     */
    public long getDbProcessDate() {
        return dbProcessDate;
    }

    /**
     * 设置dbProcessDate属性的值。
     * 
     */
    public void setDbProcessDate(long value) {
        this.dbProcessDate = value;
    }

    /**
     * 获取dbProcessUser属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbProcessUser() {
        return dbProcessUser;
    }

    /**
     * 设置dbProcessUser属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbProcessUser(String value) {
        this.dbProcessUser = value;
    }

    /**
     * 获取dbSequence属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbSequence() {
        return dbSequence;
    }

    /**
     * 设置dbSequence属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbSequence(String value) {
        this.dbSequence = value;
    }

    /**
     * 获取hid属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getHid() {
        return hid;
    }

    /**
     * 设置hid属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setHid(Long value) {
        this.hid = value;
    }

    /**
     * 获取transferDate属性的值。
     * 
     */
    public long getTransferDate() {
        return transferDate;
    }

    /**
     * 设置transferDate属性的值。
     * 
     */
    public void setTransferDate(long value) {
        this.transferDate = value;
    }

}
