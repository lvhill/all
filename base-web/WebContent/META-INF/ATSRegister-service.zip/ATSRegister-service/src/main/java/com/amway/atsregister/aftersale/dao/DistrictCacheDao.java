package com.amway.atsregister.aftersale.dao;

import java.util.List;

import com.amway.atsregister.aftersale.vo.District;

/**
 * 带缓存的省市区列表获取类
 * 
 * @author ligaofu
 *
 */
public interface DistrictCacheDao {

	/**
	 * 获取省的列表
	 * 
	 * @return
	 */
	public List<District> getProvList();

	/**
	 * 获取市的列表
	 * 
	 * @param provCode
	 *            省编码
	 * @return
	 */
	public List<District> getCitysByProvince(String provCode);

	/**
	 * 获取区县列表
	 * 
	 * @param cityCode
	 *            市编码
	 * @return
	 */
	public List<District> getTownByCity(String cityCode);

	/**
	 * 设置缓存时间(毫秒)
	 * 
	 * @param cacheTimeInterval
	 */
	public void setCacheInterval(long cacheTimeInterval);

	/**
	 * 获取缓存时间
	 * 
	 * @return
	 */
	public long getCacheInterval();

}
