package com.amway.atsregister.aftersale.service.impl;

import java.util.ArrayList;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amway.atsregister.aftersale.dao.UserRegistryExtDao;
import com.amway.atsregister.aftersale.dto.UserRegistryExt;
import com.amway.atsregister.aftersale.service.AftersaleService;
import com.amway.atsregister.aftersale.service.OrderNumService;
import com.amway.atsregister.aftersale.vo.District;
import com.amway.atsregister.aftersale.vo.Machine;
import com.amway.atsregister.aftersale.vo.UserRegistryVO;
import com.amway.atsregister.camel.UserRegistryExtProducer;

@Service("aftersaleService")
public class AftersaleServiceImpl implements AftersaleService {
	private static final Logger logger = LogManager.getLogger(AftersaleServiceImpl.class);

	@Autowired
	private UserRegistryExtDao serRegistryExtDao;

	@Autowired
	private UserRegistryExtProducer UserRegistryExtProducer;

	@Autowired
	private OrderNumService orderNumService;

	@Autowired
	private UserRegistryExtDao userRegistryExtDao;

	private SimpleDateFormat timeFormat;

	public AftersaleServiceImpl() {
		timeFormat = new SimpleDateFormat("yyyy-MM-dd");
	}

	@Override
	public void save(UserRegistryVO userRegistryVO) throws Exception {
		logger.info("com.amway.atsregister.aftersale.service.impl.AftersaleServiceImpl.save(UserRegistryVO userRegistryVO)  start!");
		List<UserRegistryExt> userRegistryExts = new ArrayList<UserRegistryExt>();

		List<Machine> machineList = userRegistryVO.getMachineList();
		List<String> orderNumList = orderNumService.getNextOrderNum(machineList.size());
		for (int i = 0; i < machineList.size(); ++i) {
			Machine machine = machineList.get(i);
			String orderNum = orderNumList.get(i);
			UserRegistryExt userRegistryExt = new UserRegistryExt();
			userRegistryExt.setCreateDate(new Date());
			userRegistryExt.setCustomerArea("");// 空值
			userRegistryExt.setCustomerAreaStr("");// 空值
			userRegistryExt.setCustomerEmail(userRegistryVO.getCustomerEmail());
			userRegistryExt.setCustomerName(userRegistryVO.getCustomerName());
			userRegistryExt.setCustomerPhone(userRegistryVO.getCustomerPhone());
			userRegistryExt.setCustomerRealAddr(userRegistryVO.getCustomerRealAddr());
			userRegistryExt.setCustomerRealCity(userRegistryVO.getCustomerRealCity());
			userRegistryExt.setCustomerRealCityStr(userRegistryVO.getCustomerRealCityStr());
			userRegistryExt.setCustomerRealProv(userRegistryVO.getCustomerRealProv());
			userRegistryExt.setCustomerRealProvStr(userRegistryVO.getCustomerRealProvStr());
			userRegistryExt.setCustomerTel(userRegistryVO.getCustomerTel());
			userRegistryExt.setCustomerTown(userRegistryVO.getCustomerTown());
			userRegistryExt.setCustomerTownStr(userRegistryVO.getCustomerTownStr());
			userRegistryExt.setHomeServiceTime(userRegistryVO.getHomeServiceTime());
			try {
				userRegistryExt.setInstallTime(timeFormat.parse(machine.getInstallTimeStr()));
			} catch (ParseException e) {
				logger.error("安装时间格式化异常.", e);
			}
			userRegistryExt.setInstallTimeStr(machine.getInstallTimeStr());
			userRegistryExt.setIsAgreeArticle(userRegistryVO.getIsAgreeArticle());
			userRegistryExt.setIsCustomer(userRegistryVO.getIsCustomer());
			userRegistryExt.setIsOpen(machine.getIsOpen());
			userRegistryExt.setManualNo(machine.getManualNo());
			userRegistryExt.setOrderNum(orderNum);
			userRegistryExt.setId(orderNum);
			// UserRegistryExt.setProductType("atsin");//固定值
			userRegistryExt.setServiceStaffContact(userRegistryVO.getServiceStaffContact());
			userRegistryExt.setServiceStaffName(userRegistryVO.getServiceStaffName());
			// UserRegistryExt.setState(0);//固定值
			userRegistryExt.setUserAdano(userRegistryVO.getUserAdano());
			userRegistryExts.add(userRegistryExt);
		}
		serRegistryExtDao.insertAll(userRegistryExts);
		logger.info(" serRegistryExtDao insertAll success! ");
		try {
			UserRegistryExtProducer.send(userRegistryExts);
		} catch (Exception e) {
			logger.error("jms消息发送失败.", e);
		}
	}

	@Override
	public List<District> getProvList() {
		return userRegistryExtDao.getProvList();
	}

	@Override
	public List<District> getCitysByProvince(String provinceId) {
		return userRegistryExtDao.getCitysByProvince(provinceId);
	}

	@Override
	public List<District> getTownByCity(String cityId) {
		return userRegistryExtDao.getTownByCity(cityId);
	}

}
