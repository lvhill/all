
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>getAicmaincInfo complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="getAicmaincInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="disNum" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="applyMth" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getAicmaincInfo", propOrder = {
    "disNum",
    "applyMth"
})
public class GetAicmaincInfo {

    protected Long disNum;
    protected int applyMth;

    /**
     * 获取disNum属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getDisNum() {
        return disNum;
    }

    /**
     * 设置disNum属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setDisNum(Long value) {
        this.disNum = value;
    }

    /**
     * 获取applyMth属性的值。
     * 
     */
    public int getApplyMth() {
        return applyMth;
    }

    /**
     * 设置applyMth属性的值。
     * 
     */
    public void setApplyMth(int value) {
        this.applyMth = value;
    }

}
