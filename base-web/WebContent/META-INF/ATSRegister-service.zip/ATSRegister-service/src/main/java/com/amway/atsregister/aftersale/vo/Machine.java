package com.amway.atsregister.aftersale.vo;

import java.io.Serializable;

/** 机器信息 */
public class Machine implements Serializable {

	private static final long serialVersionUID = 6537745043662854431L;

	/** 机身序列号 */
	private String manualNo;
	/** 是否已开封：1:是，0:否 */
	private Integer isOpen;
	/** 开始使用时间 */
	private String installTimeStr;

	public String getManualNo() {
		return manualNo;
	}

	public void setManualNo(String manualNo) {
		this.manualNo = manualNo;
	}

	public String getInstallTimeStr() {
		return installTimeStr;
	}

	public void setInstallTimeStr(String installTimeStr) {
		this.installTimeStr = installTimeStr;
	}

	public Integer getIsOpen() {
		return isOpen;
	}

	public void setIsOpen(Integer isOpen) {
		this.isOpen = isOpen;
	}

}
