
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>userBuyInfoDO complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="userBuyInfoDO">
 *   &lt;complexContent>
 *     &lt;extension base="{http://member.facade.service.ebiz.amway.com/}inquiryObject">
 *       &lt;sequence>
 *         &lt;element name="ada" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bestSalesItemDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bestSalesItemNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bestSalesQty" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="constellationCount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="firstOrderDate" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="maxSales" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="orderQty" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="pincode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="pinlvl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rsv1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rsv2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rsv3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rsv4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="salesQtyArtistry" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="salesQtyHcare" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="salesQtyNutrilite" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="salesQtyOthers" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="salesQtyPcare" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="xingzuo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "userBuyInfoDO", propOrder = {
    "ada",
    "bestSalesItemDesc",
    "bestSalesItemNo",
    "bestSalesQty",
    "constellationCount",
    "firstOrderDate",
    "id",
    "maxSales",
    "orderQty",
    "pincode",
    "pinlvl",
    "rsv1",
    "rsv2",
    "rsv3",
    "rsv4",
    "salesQtyArtistry",
    "salesQtyHcare",
    "salesQtyNutrilite",
    "salesQtyOthers",
    "salesQtyPcare",
    "xingzuo"
})
public class UserBuyInfoDO
    extends InquiryObject
{

    protected Long ada;
    protected String bestSalesItemDesc;
    protected String bestSalesItemNo;
    protected Long bestSalesQty;
    protected String constellationCount;
    protected Long firstOrderDate;
    protected Long id;
    protected Long maxSales;
    protected Long orderQty;
    protected String pincode;
    protected String pinlvl;
    protected String rsv1;
    protected String rsv2;
    protected String rsv3;
    protected String rsv4;
    protected Long salesQtyArtistry;
    protected Long salesQtyHcare;
    protected Long salesQtyNutrilite;
    protected Long salesQtyOthers;
    protected Long salesQtyPcare;
    protected String xingzuo;

    /**
     * 获取ada属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAda() {
        return ada;
    }

    /**
     * 设置ada属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAda(Long value) {
        this.ada = value;
    }

    /**
     * 获取bestSalesItemDesc属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBestSalesItemDesc() {
        return bestSalesItemDesc;
    }

    /**
     * 设置bestSalesItemDesc属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBestSalesItemDesc(String value) {
        this.bestSalesItemDesc = value;
    }

    /**
     * 获取bestSalesItemNo属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBestSalesItemNo() {
        return bestSalesItemNo;
    }

    /**
     * 设置bestSalesItemNo属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBestSalesItemNo(String value) {
        this.bestSalesItemNo = value;
    }

    /**
     * 获取bestSalesQty属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getBestSalesQty() {
        return bestSalesQty;
    }

    /**
     * 设置bestSalesQty属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setBestSalesQty(Long value) {
        this.bestSalesQty = value;
    }

    /**
     * 获取constellationCount属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConstellationCount() {
        return constellationCount;
    }

    /**
     * 设置constellationCount属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConstellationCount(String value) {
        this.constellationCount = value;
    }

    /**
     * 获取firstOrderDate属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getFirstOrderDate() {
        return firstOrderDate;
    }

    /**
     * 设置firstOrderDate属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setFirstOrderDate(Long value) {
        this.firstOrderDate = value;
    }

    /**
     * 获取id属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置id属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setId(Long value) {
        this.id = value;
    }

    /**
     * 获取maxSales属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getMaxSales() {
        return maxSales;
    }

    /**
     * 设置maxSales属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setMaxSales(Long value) {
        this.maxSales = value;
    }

    /**
     * 获取orderQty属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getOrderQty() {
        return orderQty;
    }

    /**
     * 设置orderQty属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setOrderQty(Long value) {
        this.orderQty = value;
    }

    /**
     * 获取pincode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPincode() {
        return pincode;
    }

    /**
     * 设置pincode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPincode(String value) {
        this.pincode = value;
    }

    /**
     * 获取pinlvl属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPinlvl() {
        return pinlvl;
    }

    /**
     * 设置pinlvl属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPinlvl(String value) {
        this.pinlvl = value;
    }

    /**
     * 获取rsv1属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRsv1() {
        return rsv1;
    }

    /**
     * 设置rsv1属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRsv1(String value) {
        this.rsv1 = value;
    }

    /**
     * 获取rsv2属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRsv2() {
        return rsv2;
    }

    /**
     * 设置rsv2属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRsv2(String value) {
        this.rsv2 = value;
    }

    /**
     * 获取rsv3属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRsv3() {
        return rsv3;
    }

    /**
     * 设置rsv3属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRsv3(String value) {
        this.rsv3 = value;
    }

    /**
     * 获取rsv4属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRsv4() {
        return rsv4;
    }

    /**
     * 设置rsv4属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRsv4(String value) {
        this.rsv4 = value;
    }

    /**
     * 获取salesQtyArtistry属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getSalesQtyArtistry() {
        return salesQtyArtistry;
    }

    /**
     * 设置salesQtyArtistry属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setSalesQtyArtistry(Long value) {
        this.salesQtyArtistry = value;
    }

    /**
     * 获取salesQtyHcare属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getSalesQtyHcare() {
        return salesQtyHcare;
    }

    /**
     * 设置salesQtyHcare属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setSalesQtyHcare(Long value) {
        this.salesQtyHcare = value;
    }

    /**
     * 获取salesQtyNutrilite属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getSalesQtyNutrilite() {
        return salesQtyNutrilite;
    }

    /**
     * 设置salesQtyNutrilite属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setSalesQtyNutrilite(Long value) {
        this.salesQtyNutrilite = value;
    }

    /**
     * 获取salesQtyOthers属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getSalesQtyOthers() {
        return salesQtyOthers;
    }

    /**
     * 设置salesQtyOthers属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setSalesQtyOthers(Long value) {
        this.salesQtyOthers = value;
    }

    /**
     * 获取salesQtyPcare属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getSalesQtyPcare() {
        return salesQtyPcare;
    }

    /**
     * 设置salesQtyPcare属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setSalesQtyPcare(Long value) {
        this.salesQtyPcare = value;
    }

    /**
     * 获取xingzuo属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXingzuo() {
        return xingzuo;
    }

    /**
     * 设置xingzuo属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXingzuo(String value) {
        this.xingzuo = value;
    }

}
