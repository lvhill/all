/**
 * 文件名：UserRegistry 描述：用户注册model 创建时间：2012/3/30 作者： big pig
 */
package com.amway.atsregister.aftersale.dto;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * 类功能描述：用户注册model
 * 
 * @author big pig
 * @date 2012/3/30
 * @version 1.0
 */
@Document
public class UserRegistryExt implements Serializable {

	private static final long serialVersionUID = 8679944882613255597L;

	// 主键
	@Id
	private String id;
	// 传给海尔的单号
	@Field
	private String orderNum;
	// 服务手册登记号
	@Field
	private String manualNo;
	// 创建日期, 即用户页面提交登记信息时间
	@Field
	private Date createDate;
	// 使用者安利卡号
	@Field
	private String userAdano;

	// 使用者电话
	@Field
	private String customerPhone;
	// 使用者手机号
	@Field
	private String customerTel;
	// 使用者email
	@Field
	private String customerEmail;
	// 产品使用区域
	@Field
	private String customerArea;
	@Field
	private String customerAreaStr;
	// 产品使用省
	@Field
	private String customerRealProv;
	@Field
	private String customerRealProvStr;
	// 产品使用城市
	@Field
	private String customerRealCity;
	@Field
	private String customerRealCityStr;
	// 使用者区县
	@Field
	private String customerTown;
	@Field
	private String customerTownStr;
	// 产品使用地址
	@Field
	private String customerRealAddr;
	// 使用者姓名
	@Field
	private String customerName;

	// 安装时间，即开始使用时间
	@Field
	private Date installTime;
	// 安装时间str
	@Field
	private String installTimeStr;
	/** 您是否是安利销售代表、经销商或优惠顾客：0:否，1:是 */
	@Field
	private Integer isCustomer;
	/** 是否同意条款：0:否，1:是 */
	@Field
	private Integer isAgreeArticle;

	/** 产品类型：wts，ats，atsin */
	@Field
	private String productType = "atsin";
	/** 是否已开封：1:是，0:否 */
	@Field
	private Integer isOpen;
	/** 上门服务时间：1:工作日，2:周末，3:工作日周末皆可 */
	@Field
	private Integer homeServiceTime;
	// 营销人员的姓名
	@Field
	private String serviceStaffName;
	// 营销人员的联系方式
	@Field
	private String serviceStaffContact;
	// 数据是否上传; 0=还没上传 , 1=已经上传
	@Field
	private Integer state = 0;

	public String getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}

	public String getManualNo() {
		return manualNo;
	}

	public void setManualNo(String manualNo) {
		this.manualNo = manualNo;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getUserAdano() {
		return userAdano;
	}

	public void setUserAdano(String userAdano) {
		this.userAdano = userAdano;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getCustomerTel() {
		return customerTel;
	}

	public void setCustomerTel(String customerTel) {
		this.customerTel = customerTel;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerArea() {
		return customerArea;
	}

	public void setCustomerArea(String customerArea) {
		this.customerArea = customerArea;
	}

	public String getCustomerAreaStr() {
		return customerAreaStr;
	}

	public void setCustomerAreaStr(String customerAreaStr) {
		this.customerAreaStr = customerAreaStr;
	}

	public String getCustomerRealProv() {
		return customerRealProv;
	}

	public void setCustomerRealProv(String customerRealProv) {
		this.customerRealProv = customerRealProv;
	}

	public String getCustomerRealProvStr() {
		return customerRealProvStr;
	}

	public void setCustomerRealProvStr(String customerRealProvStr) {
		this.customerRealProvStr = customerRealProvStr;
	}

	public String getCustomerRealCity() {
		return customerRealCity;
	}

	public void setCustomerRealCity(String customerRealCity) {
		this.customerRealCity = customerRealCity;
	}

	public String getCustomerRealCityStr() {
		return customerRealCityStr;
	}

	public void setCustomerRealCityStr(String customerRealCityStr) {
		this.customerRealCityStr = customerRealCityStr;
	}

	public String getCustomerTown() {
		return customerTown;
	}

	public void setCustomerTown(String customerTown) {
		this.customerTown = customerTown;
	}

	public String getCustomerTownStr() {
		return customerTownStr;
	}

	public void setCustomerTownStr(String customerTownStr) {
		this.customerTownStr = customerTownStr;
	}

	public String getCustomerRealAddr() {
		return customerRealAddr;
	}

	public void setCustomerRealAddr(String customerRealAddr) {
		this.customerRealAddr = customerRealAddr;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Date getInstallTime() {
		return installTime;
	}

	public void setInstallTime(Date installTime) {
		this.installTime = installTime;
	}

	public String getInstallTimeStr() {
		return installTimeStr;
	}

	public void setInstallTimeStr(String installTimeStr) {
		this.installTimeStr = installTimeStr;
	}

	public Integer getIsCustomer() {
		return isCustomer;
	}

	public void setIsCustomer(Integer isCustomer) {
		this.isCustomer = isCustomer;
	}

	public Integer getIsAgreeArticle() {
		return isAgreeArticle;
	}

	public void setIsAgreeArticle(Integer isAgreeArticle) {
		this.isAgreeArticle = isAgreeArticle;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public Integer getIsOpen() {
		return isOpen;
	}

	public void setIsOpen(Integer isOpen) {
		this.isOpen = isOpen;
	}

	public Integer getHomeServiceTime() {
		return homeServiceTime;
	}

	public void setHomeServiceTime(Integer homeServiceTime) {
		this.homeServiceTime = homeServiceTime;
	}

	public String getServiceStaffName() {
		return serviceStaffName;
	}

	public void setServiceStaffName(String serviceStaffName) {
		this.serviceStaffName = serviceStaffName;
	}

	public String getServiceStaffContact() {
		return serviceStaffContact;
	}

	public void setServiceStaffContact(String serviceStaffContact) {
		this.serviceStaffContact = serviceStaffContact;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
