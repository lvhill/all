
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>memberInfo complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="memberInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ada" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="dstTypCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="expiryDte" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="joinDte" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="latestRenewDte" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="mbrStsCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mstPersonId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="ordDte" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="pendingEndDoaedk" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="pendingExpDoaedk" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="pickupCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="puCtrCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="puCtrName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="qvsCurrFinYear" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="qvsPinLvl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="qvsPinlvlDsc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="signupCtrCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="signupCtrName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="spousePersonId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="violate" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "memberInfo", propOrder = {
    "ada",
    "dstTypCde",
    "expiryDte",
    "joinDte",
    "latestRenewDte",
    "mbrStsCde",
    "mstPersonId",
    "ordDte",
    "pendingEndDoaedk",
    "pendingExpDoaedk",
    "pickupCde",
    "puCtrCde",
    "puCtrName",
    "qvsCurrFinYear",
    "qvsPinLvl",
    "qvsPinlvlDsc",
    "signupCtrCde",
    "signupCtrName",
    "spousePersonId",
    "violate"
})
public class MemberInfo {

    protected Long ada;
    protected String dstTypCde;
    protected int expiryDte;
    protected int joinDte;
    protected int latestRenewDte;
    protected String mbrStsCde;
    protected Long mstPersonId;
    protected int ordDte;
    protected int pendingEndDoaedk;
    protected int pendingExpDoaedk;
    protected String pickupCde;
    protected String puCtrCde;
    protected String puCtrName;
    protected String qvsCurrFinYear;
    protected String qvsPinLvl;
    protected String qvsPinlvlDsc;
    protected String signupCtrCde;
    protected String signupCtrName;
    protected Long spousePersonId;
    protected boolean violate;

    /**
     * 获取ada属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAda() {
        return ada;
    }

    /**
     * 设置ada属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAda(Long value) {
        this.ada = value;
    }

    /**
     * 获取dstTypCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDstTypCde() {
        return dstTypCde;
    }

    /**
     * 设置dstTypCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDstTypCde(String value) {
        this.dstTypCde = value;
    }

    /**
     * 获取expiryDte属性的值。
     * 
     */
    public int getExpiryDte() {
        return expiryDte;
    }

    /**
     * 设置expiryDte属性的值。
     * 
     */
    public void setExpiryDte(int value) {
        this.expiryDte = value;
    }

    /**
     * 获取joinDte属性的值。
     * 
     */
    public int getJoinDte() {
        return joinDte;
    }

    /**
     * 设置joinDte属性的值。
     * 
     */
    public void setJoinDte(int value) {
        this.joinDte = value;
    }

    /**
     * 获取latestRenewDte属性的值。
     * 
     */
    public int getLatestRenewDte() {
        return latestRenewDte;
    }

    /**
     * 设置latestRenewDte属性的值。
     * 
     */
    public void setLatestRenewDte(int value) {
        this.latestRenewDte = value;
    }

    /**
     * 获取mbrStsCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMbrStsCde() {
        return mbrStsCde;
    }

    /**
     * 设置mbrStsCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMbrStsCde(String value) {
        this.mbrStsCde = value;
    }

    /**
     * 获取mstPersonId属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getMstPersonId() {
        return mstPersonId;
    }

    /**
     * 设置mstPersonId属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setMstPersonId(Long value) {
        this.mstPersonId = value;
    }

    /**
     * 获取ordDte属性的值。
     * 
     */
    public int getOrdDte() {
        return ordDte;
    }

    /**
     * 设置ordDte属性的值。
     * 
     */
    public void setOrdDte(int value) {
        this.ordDte = value;
    }

    /**
     * 获取pendingEndDoaedk属性的值。
     * 
     */
    public int getPendingEndDoaedk() {
        return pendingEndDoaedk;
    }

    /**
     * 设置pendingEndDoaedk属性的值。
     * 
     */
    public void setPendingEndDoaedk(int value) {
        this.pendingEndDoaedk = value;
    }

    /**
     * 获取pendingExpDoaedk属性的值。
     * 
     */
    public int getPendingExpDoaedk() {
        return pendingExpDoaedk;
    }

    /**
     * 设置pendingExpDoaedk属性的值。
     * 
     */
    public void setPendingExpDoaedk(int value) {
        this.pendingExpDoaedk = value;
    }

    /**
     * 获取pickupCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPickupCde() {
        return pickupCde;
    }

    /**
     * 设置pickupCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPickupCde(String value) {
        this.pickupCde = value;
    }

    /**
     * 获取puCtrCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPuCtrCde() {
        return puCtrCde;
    }

    /**
     * 设置puCtrCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPuCtrCde(String value) {
        this.puCtrCde = value;
    }

    /**
     * 获取puCtrName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPuCtrName() {
        return puCtrName;
    }

    /**
     * 设置puCtrName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPuCtrName(String value) {
        this.puCtrName = value;
    }

    /**
     * 获取qvsCurrFinYear属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQvsCurrFinYear() {
        return qvsCurrFinYear;
    }

    /**
     * 设置qvsCurrFinYear属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQvsCurrFinYear(String value) {
        this.qvsCurrFinYear = value;
    }

    /**
     * 获取qvsPinLvl属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQvsPinLvl() {
        return qvsPinLvl;
    }

    /**
     * 设置qvsPinLvl属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQvsPinLvl(String value) {
        this.qvsPinLvl = value;
    }

    /**
     * 获取qvsPinlvlDsc属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQvsPinlvlDsc() {
        return qvsPinlvlDsc;
    }

    /**
     * 设置qvsPinlvlDsc属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQvsPinlvlDsc(String value) {
        this.qvsPinlvlDsc = value;
    }

    /**
     * 获取signupCtrCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignupCtrCde() {
        return signupCtrCde;
    }

    /**
     * 设置signupCtrCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignupCtrCde(String value) {
        this.signupCtrCde = value;
    }

    /**
     * 获取signupCtrName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignupCtrName() {
        return signupCtrName;
    }

    /**
     * 设置signupCtrName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignupCtrName(String value) {
        this.signupCtrName = value;
    }

    /**
     * 获取spousePersonId属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getSpousePersonId() {
        return spousePersonId;
    }

    /**
     * 设置spousePersonId属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setSpousePersonId(Long value) {
        this.spousePersonId = value;
    }

    /**
     * 获取violate属性的值。
     * 
     */
    public boolean isViolate() {
        return violate;
    }

    /**
     * 设置violate属性的值。
     * 
     */
    public void setViolate(boolean value) {
        this.violate = value;
    }

}
