
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>bankAcc complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="bankAcc">
 *   &lt;complexContent>
 *     &lt;extension base="{http://member.facade.service.ebiz.amway.com/}inquiryObject">
 *       &lt;sequence>
 *         &lt;element name="accNam" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ada" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bankAccId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bankAccStsCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bankBrhDsc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bankAcc", propOrder = {
    "accNam",
    "accNum",
    "ada",
    "bankAccId",
    "bankAccStsCde",
    "bankBrhDsc"
})
public class BankAcc
    extends InquiryObject
{

    protected String accNam;
    protected String accNum;
    protected Long ada;
    protected Long bankAccId;
    protected String bankAccStsCde;
    protected String bankBrhDsc;

    /**
     * 获取accNam属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccNam() {
        return accNam;
    }

    /**
     * 设置accNam属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccNam(String value) {
        this.accNam = value;
    }

    /**
     * 获取accNum属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccNum() {
        return accNum;
    }

    /**
     * 设置accNum属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccNum(String value) {
        this.accNum = value;
    }

    /**
     * 获取ada属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAda() {
        return ada;
    }

    /**
     * 设置ada属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAda(Long value) {
        this.ada = value;
    }

    /**
     * 获取bankAccId属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getBankAccId() {
        return bankAccId;
    }

    /**
     * 设置bankAccId属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setBankAccId(Long value) {
        this.bankAccId = value;
    }

    /**
     * 获取bankAccStsCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankAccStsCde() {
        return bankAccStsCde;
    }

    /**
     * 设置bankAccStsCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankAccStsCde(String value) {
        this.bankAccStsCde = value;
    }

    /**
     * 获取bankBrhDsc属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankBrhDsc() {
        return bankBrhDsc;
    }

    /**
     * 设置bankBrhDsc属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankBrhDsc(String value) {
        this.bankBrhDsc = value;
    }

}
