package com.amway.atsregister.aftersale.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amway.atsregister.aftersale.dao.UserRegistryExtDao;
import com.amway.atsregister.aftersale.service.OrderNumService;
import com.amway.atsregister.aftersale.vo.OrderNumVo;
import com.amway.atsregister.hazelcast.MyHazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.ILock;
import com.hazelcast.core.IMap;

@Service("OrderNumServiceImpl")
public class OrderNumServiceImpl implements OrderNumService {
	private static final Logger logger = LoggerFactory.getLogger(OrderNumServiceImpl.class);

	@Autowired
	private UserRegistryExtDao userRegistryExtDao;

	/**
	 * 工单号后面数字位数,A2017040200001, 数据格式: 'A'+'yyyyMMdd'+00001 (00001 自增)
	 */
	private static int orderNumlength = 7;

	private SimpleDateFormat timeFormat;

	public final static String OrderNumVo_Map = "HAZELCAST_ORDERNUMVO_MAP";
	public final static String OrderNumVo_Map_Key = "HAZELCAST_ORDERNUMVO_MAP_KEY";
	public final static String Hazelcstt_Next_Ordernum_Lockey = "HAZELCAST_NEXT_ORDERNUM_LOCKEY";

	private OrderNumServiceImpl() {
		timeFormat = new SimpleDateFormat("yyyyMMdd");
	}

	private void initHazelcastOrderNumVo() {
		HazelcastInstance instance = MyHazelcast.getHazelcastInstance();
		if (instance != null) {
			IMap<String, OrderNumVo> nextOrderNumMap = instance.getMap(OrderNumVo_Map);
			if (nextOrderNumMap == null || nextOrderNumMap.size() == 0) {
				OrderNumVo orderNumVo = new OrderNumVo();

				String nextOrdernum = getNextOrdernum(new Date());
				orderNumVo.setDate(nextOrdernum.substring(1, 9));
				int num = Integer.valueOf(nextOrdernum.substring(9));
				orderNumVo.setNum(num);

				nextOrderNumMap.put(OrderNumVo_Map_Key, orderNumVo);
			}
		}
	}

	public List<String> getNextOrderNum(int size) throws Exception {
		logger.info("com.amway.atsregister.aftersale.service.impl.OrderNumServiceImpl.getNextOrderNum start! ");
		String orderNum = "";
		boolean isGetLock;

		HazelcastInstance instance = MyHazelcast.getHazelcastInstance();
		logger.info("HazelcastInstance: " + instance.toString());
		ILock ilock = instance.getLock(Hazelcstt_Next_Ordernum_Lockey);
		Date begintime = new Date();
		long interval = 0;
		do {
			isGetLock = ilock.tryLock();
			if (isGetLock) {
				logger.info("取得Hazelcstt_Next_Ordernum_Lockey锁, 执行业务代码 start!");

				IMap<String, OrderNumVo> nextOrderNumMap = instance.getMap(OrderNumVo_Map);
				OrderNumVo orderNumVo = nextOrderNumMap.get(OrderNumVo_Map_Key);
				if (orderNumVo == null) {
					initHazelcastOrderNumVo();
					orderNumVo = nextOrderNumMap.get(OrderNumVo_Map_Key);
				}
				orderNum = "A" + orderNumVo.getDate() + String.format("%0" + orderNumlength + "d", orderNumVo.getNum());// 凑0补齐orderNumlength位数
				logger.info("从HazelcastInstance里面取得的下一个工单号为: " + orderNum);

				// 设置下一个工单号
				String now = timeFormat.format(new Date());
				int num = 0;
				if (now.equals(orderNumVo.getDate())) {
					num = orderNumVo.getNum() + size;
				} else {
					num = 1 + size;
				}
				orderNumVo.setDate(now);
				orderNumVo.setNum(num);

				nextOrderNumMap.put(OrderNumVo_Map_Key, orderNumVo);

				logger.info("释放Hazelcstt_Next_Ordernum_Lockey锁, 执行业务代码 end!");
				ilock.unlock();
			} else {
				interval = new Date().getTime() - begintime.getTime(); // 尝试取锁时间(毫秒)
			}
		} while (interval < 30000 && !isGetLock);
		logger.info("尝试取得Hazelcstt_Next_Ordernum_Lockey锁的时间(毫秒): " + interval);
		if (!isGetLock) {
			logger.error("未取到Hazelcstt_Next_Ordernum_Lockey锁, 且尝试取锁时间超过30秒, 抛出 '取工单号超时' 异常.");
			throw new Exception("取工单号超时");
		}
		//
		List<String> list = new ArrayList<String>();
		list.add(orderNum);
		String next = orderNum;
		for (int i = 1; i < size; ++i) {
			next = getNextOrdernum(next);
			list.add(next);
		}
		logger.info("com.amway.atsregister.aftersale.service.impl.OrderNumServiceImpl.getNextOrderNum end! ");
		return list;
	}

	/**
	 * 计算某天下一个最大工单号
	 * 
	 * @param date
	 * @return
	 */
	private String getNextOrdernum(Date date) {
		String nextOrderNum = "";
		String maxOrderNum = userRegistryExtDao.getMaxOrderNum(date);

		if (maxOrderNum.length() == 0) {
			SimpleDateFormat timeFormat = new SimpleDateFormat("yyyyMMdd");
			String time = timeFormat.format(date);
			String numb = String.format("%0" + orderNumlength + "d", 1);// 凑0补齐orderNumlength位数
			nextOrderNum = "A" + time + numb;
		} else {
			nextOrderNum = getNextOrdernum(maxOrderNum);
		}
		logger.info("nextOrderNum: " + nextOrderNum);
		return nextOrderNum;
	}

	/**
	 * 计算orderNum的下一个工单号
	 * 
	 * @param orderNum
	 * @return
	 */
	private String getNextOrdernum(String orderNum) {
		String nextOrderNum = "";

		// AyyyyMMdd , 工单号前面9位数是固定的
		String adate = orderNum.substring(0, 9);
		String numb = orderNum.substring(9);
		int num = Integer.valueOf(numb);
		numb = String.format("%0" + orderNumlength + "d", ++num);// 凑0补齐orderNumlength位数
		nextOrderNum = adate + numb;

		return nextOrderNum;
	}

}
