package com.amway.atsregister.aftersale.controller;

import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.amway.atsregister.aftersale.service.AftersaleService;
import com.amway.atsregister.aftersale.vo.District;
import com.amway.atsregister.aftersale.vo.WebParam;
import com.amway.atsregister.aftersale.vo.UserRegistryVO;
import com.amway.atsregister.common.util.RandomValidateCode;
import com.amway.atsregister.hazelcast.MyHazelcast;
import com.amway.atsregister.ws.client.SoapHanderClient;
import com.google.gson.Gson;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IQueue;

import io.swagger.annotations.ApiOperation;
import net.sf.json.JSONObject;

@Controller
public class AftersaleController {
	private static final Logger logger = LogManager.getLogger(AftersaleController.class);

	private final static String ValidateCode = "ATSREGISTER_VALIDATECODE";

	private Gson gson = new Gson();

	@Autowired
	private AftersaleService aftersaleService;

	@ApiOperation(value = "逸新空气净化器售后服务登记提交", notes = "逸新空气净化器售后服务登记提交", response = String.class, tags = {})
	@RequestMapping(value = "/aftersaleRegister", method = RequestMethod.POST)
	public ResponseEntity<String> aftersaleRegister(HttpServletRequest request, HttpServletResponse response,
			WebParam webParam) {
		logger.info("com.amway.atsregister.aftersale.controller.AftersaleController.aftersaleRegister start!");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		// headers.setAccessControlAllowOrigin("*");

		String jsonStr = webParam.getData();
		logger.info("接收入参: " + jsonStr);
		UserRegistryVO serRegistryVO = null;
		try {
			serRegistryVO = gson.fromJson(jsonStr, UserRegistryVO.class);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("入参json转换成 UserRegistryVO.class 异常.", e);
			return new ResponseEntity<String>("500", headers, HttpStatus.OK);
		}

		// 验证码
		String randomCode = serRegistryVO.getRandomCode();
		HttpSession session = request.getSession();
		logger.info(session.getId());
		String seesionRandomCode = (String) session.getAttribute(ValidateCode);
		if (randomCode == null || !randomCode.equalsIgnoreCase(seesionRandomCode)) {
			logger.info("前台传参验证码randomCode :" + randomCode + ", seesionRandomCode :" + seesionRandomCode
					+ ", 参数验证码和session验证码不一致, 返回451 -- 验证码错误");
			return new ResponseEntity<String>("451", headers, HttpStatus.OK);// 验证码不正确
		}

		// 安利号
		String adaNo = serRegistryVO.getUserAdano();
		Integer isCustomer = serRegistryVO.getIsCustomer();
		if (isCustomer.intValue() == 1 && !checkAda(adaNo)) {
			logger.info("安利号adaNo:" + adaNo + ", 安利号无效返回418 -- 安利号无效");
			return new ResponseEntity<String>("418", headers, HttpStatus.OK);
		}
		try {
			HazelcastInstance instance = MyHazelcast.getHazelcastInstance();
			IQueue<UserRegistryVO> queue = instance.getQueue("UserRegistryVO_QUEUE");
			queue.offer(serRegistryVO, 1000 * 1, TimeUnit.MILLISECONDS);
		} catch (Exception e) {
			logger.error("数据入库异常.", e);
			return new ResponseEntity<String>("500", headers, HttpStatus.OK);
		}
		// 200 保存成功
		logger.info("com.amway.atsregister.aftersale.controller.AftersaleController.aftersaleRegister end!");
		return new ResponseEntity<String>("200", headers, HttpStatus.OK);
	}

	@ApiOperation(value = "检查安利号是否有效", notes = "检查安利号是否有效", response = String.class, tags = {})
	@RequestMapping(value = "/checkAdaNo", method = RequestMethod.POST)
	public ResponseEntity<String> checkAdaNo(WebParam webParam) {
		logger.info("com.amway.atsregister.aftersale.controller.AftersaleController.checkAdaNo start!");
		String jsonStr = webParam.getData();
		logger.info("接受入参: " + jsonStr);

		JSONObject json = JSONObject.fromObject(jsonStr);
		String adaNo = json.getString("adaNo");
		boolean isAdaExist = checkAda(adaNo);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		// headers.setAccessControlAllowOrigin("*");
		if (isAdaExist) {
			logger.info("安利号adaNo:" + adaNo + "校验成功, 返回 200.");
			return new ResponseEntity<String>("200", headers, HttpStatus.OK);
		}
		logger.info("安利号adaNo:" + adaNo + ", 安利号无效返回418 -- 安利号无效");
		logger.info("com.amway.atsregister.aftersale.controller.AftersaleController.checkAdaNo end!");
		return new ResponseEntity<String>("418", headers, HttpStatus.OK);
	}

	/**
	 * 校验安利号是否有效
	 * 
	 * @param adano
	 * @return 有效true, 无效false
	 */
	private boolean checkAda(String adano) {
		if (adano == null || adano.length() == 0) {
			return false;
		}
		boolean isAdaExist = SoapHanderClient.retrieveMember(adano);
		return isAdaExist;
	}

	@ApiOperation(value = "获取省份列表", notes = "获取省份列表", response = String.class, tags = {})
	@RequestMapping(value = "/getProvList", method = RequestMethod.POST)
	public ResponseEntity<List<District>> getProvList() {
		logger.info("com.amway.atsregister.aftersale.controller.AftersaleController.getProvList start!");
		List<District> provList = aftersaleService.getProvList();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		// headers.setAccessControlAllowOrigin("*");
		logger.info("com.amway.atsregister.aftersale.controller.AftersaleController.getProvList end!");
		return new ResponseEntity<List<District>>(provList, headers, HttpStatus.OK);
	}

	@ApiOperation(value = "获取市列表", notes = "获取市列表", response = String.class, tags = {})
	@RequestMapping(value = "/getCityList", method = RequestMethod.POST)
	public ResponseEntity<List<District>> getCityList(WebParam webParam) {
		logger.info("com.amway.atsregister.aftersale.controller.AftersaleController.getCityList start!");
		String jsonStr = webParam.getData();
		logger.info("接受入参: " + jsonStr);
		JSONObject json = JSONObject.fromObject(jsonStr);
		String districtCode = json.getString("districtCode");
		List<District> cityList = aftersaleService.getCitysByProvince(districtCode);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		// headers.setAccessControlAllowOrigin("*");
		logger.info("com.amway.atsregister.aftersale.controller.AftersaleController.getCityList end!");
		return new ResponseEntity<List<District>>(cityList, headers, HttpStatus.OK);
	}

	@ApiOperation(value = "获取区县列表", notes = "获取区县列表", response = String.class, tags = {})
	@RequestMapping(value = "/getTownList", method = RequestMethod.POST)
	public ResponseEntity<List<District>> getTownList(WebParam webParam) {
		logger.info("com.amway.atsregister.aftersale.controller.AftersaleController.getTownList start!");
		String jsonStr = webParam.getData();
		logger.info("接受入参: " + jsonStr);
		JSONObject json = JSONObject.fromObject(jsonStr);
		String districtCode = json.getString("districtCode");
		List<District> townList = aftersaleService.getTownByCity(districtCode);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		// headers.setAccessControlAllowOrigin("*");
		logger.info("com.amway.atsregister.aftersale.controller.AftersaleController.getTownList end!");
		return new ResponseEntity<List<District>>(townList, headers, HttpStatus.OK);
	}

	@ApiOperation(value = "获取验证码图片", notes = "获取验证码图片", response = String.class, tags = {})
	@RequestMapping(value = "/openRandomCode")
	@ResponseBody
	public ResponseEntity<String> openRandomCode(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();

		response.setContentType("image/jpeg");// 设置相应类型,告诉浏览器输出的内容为图片
		response.setHeader("Pragma", "No-cache");// 设置响应头信息，告诉浏览器不要缓存此内容
		response.setHeader("Cache-Control", "no-cache");
		response.setDateHeader("Expire", 0);
		//
		RandomValidateCode validateCode = new RandomValidateCode();
		session.removeAttribute(ValidateCode);
		session.setAttribute(ValidateCode, validateCode.getValidateCode());
		try {
			ImageIO.write(validateCode.getValidateCodeImg(), "JPEG", response.getOutputStream());// 将内存中的图片通过流动形式输出到客户端
		} catch (Exception e) {
			logger.error("验证码生成异常.", e);
		}
		logger.info(session.getId());
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		// headers.setAccessControlAllowOrigin("*");
		return new ResponseEntity<String>(headers, HttpStatus.OK);
	}

}
