
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>memberHistory complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="memberHistory">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ada" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="audit_Code" type="{http://member.facade.service.ebiz.amway.com/}auditCode" minOccurs="0"/>
 *         &lt;element name="CName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DB_Batch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DB_Date" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="DB_Process_Date" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="DB_Process_User" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DB_Sequence" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "memberHistory", propOrder = {
    "ada",
    "auditCode",
    "cName",
    "dbBatch",
    "dbDate",
    "dbProcessDate",
    "dbProcessUser",
    "dbSequence",
    "eName"
})
public class MemberHistory {

    protected Long ada;
    @XmlElement(name = "audit_Code")
    protected AuditCode auditCode;
    @XmlElement(name = "CName")
    protected String cName;
    @XmlElement(name = "DB_Batch")
    protected String dbBatch;
    @XmlElement(name = "DB_Date")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dbDate;
    @XmlElement(name = "DB_Process_Date")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dbProcessDate;
    @XmlElement(name = "DB_Process_User")
    protected String dbProcessUser;
    @XmlElement(name = "DB_Sequence")
    protected String dbSequence;
    @XmlElement(name = "EName")
    protected String eName;

    /**
     * 获取ada属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAda() {
        return ada;
    }

    /**
     * 设置ada属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAda(Long value) {
        this.ada = value;
    }

    /**
     * 获取auditCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link AuditCode }
     *     
     */
    public AuditCode getAuditCode() {
        return auditCode;
    }

    /**
     * 设置auditCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link AuditCode }
     *     
     */
    public void setAuditCode(AuditCode value) {
        this.auditCode = value;
    }

    /**
     * 获取cName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCName() {
        return cName;
    }

    /**
     * 设置cName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCName(String value) {
        this.cName = value;
    }

    /**
     * 获取dbBatch属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDBBatch() {
        return dbBatch;
    }

    /**
     * 设置dbBatch属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDBBatch(String value) {
        this.dbBatch = value;
    }

    /**
     * 获取dbDate属性的值。
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDBDate() {
        return dbDate;
    }

    /**
     * 设置dbDate属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDBDate(XMLGregorianCalendar value) {
        this.dbDate = value;
    }

    /**
     * 获取dbProcessDate属性的值。
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDBProcessDate() {
        return dbProcessDate;
    }

    /**
     * 设置dbProcessDate属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDBProcessDate(XMLGregorianCalendar value) {
        this.dbProcessDate = value;
    }

    /**
     * 获取dbProcessUser属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDBProcessUser() {
        return dbProcessUser;
    }

    /**
     * 设置dbProcessUser属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDBProcessUser(String value) {
        this.dbProcessUser = value;
    }

    /**
     * 获取dbSequence属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDBSequence() {
        return dbSequence;
    }

    /**
     * 设置dbSequence属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDBSequence(String value) {
        this.dbSequence = value;
    }

    /**
     * 获取eName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEName() {
        return eName;
    }

    /**
     * 设置eName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEName(String value) {
        this.eName = value;
    }

}
