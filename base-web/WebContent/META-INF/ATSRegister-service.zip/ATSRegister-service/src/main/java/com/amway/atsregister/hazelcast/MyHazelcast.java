package com.amway.atsregister.hazelcast;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.config.ClasspathXmlConfig;
import com.hazelcast.config.Config;
import com.hazelcast.config.GroupConfig;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;

/**
 * Hazelcast
 * 
 * @author xl,xu
 * 
 */
public class MyHazelcast {

    private final static String HAZELCAST = "hazelcast.xml";

    private static Logger logger = LoggerFactory.getLogger(MyHazelcast.class);

    private HazelcastInstance instance = null;
    
    private static MyHazelcast myHazelcast = new MyHazelcast();
    
    public MyHazelcast()
    {
    	initHazelcastInstance();
    }
    
    
    public synchronized static HazelcastInstance getHazelcastInstance()
    {
    	if(null == myHazelcast.instance)
    	{
    		myHazelcast.initHazelcastInstance();
    	}
    	return myHazelcast.instance;
    }
    
    
    
    public synchronized void initHazelcastInstance() {
        try {
            Config config1 = new ClasspathXmlConfig(MyHazelcast.HAZELCAST);
            int port = config1.getNetworkConfig().getPort();
            String ip = InetAddress.getLocalHost().getHostAddress();
            String address = ip + ":" + port;

            ClientConfig configClient = new ClientConfig();
            GroupConfig groupConfig =
                    new GroupConfig(config1.getGroupConfig().getName(), config1.getGroupConfig().getPassword());
            configClient.setGroupConfig(groupConfig);
            configClient.getNetworkConfig().addAddress(address);
            try {
                instance = HazelcastClient.newHazelcastClient(configClient);
                logger.info("-----------------HazelcastInstance connect success----------------hazelcastInstance:"
                        + instance.getName() + "    address:" + address);
            } catch (IllegalStateException e) {
                logger.error("-----------------HazelcastInstance connect fail-----------------", e);
            }
            if (null == instance) {

                try {
                    logger.info("-----------------new HazelcastInstance --------address:" + address);
                    instance = Hazelcast.newHazelcastInstance(config1);
                } catch (Exception e) {
                    logger.error("-----------------new HazelcastInstance fail--------address:" + address, e);
                }
                initHazelcastInstance();
            }

        } catch (UnknownHostException e) {
            logger.error("---------method--------initHazelcastInstance --------", e);
        } catch (Exception e) {
            logger.error("----------method-------initHazelcastInstance -----------------", e);
        }
    }

    public static void main(String[] args) {
        MyHazelcast m = new MyHazelcast();
        m.initHazelcastInstance();
        int i = 0;
        while (true) {
            try {
                Thread.sleep(1000 * 5L);
                Map<String, String> map = m.instance.getMap("test");
                System.out.println(map.get("key1"));


                map = m.instance.getMap("test");
                map.put("key1", "value" + i++);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


}
