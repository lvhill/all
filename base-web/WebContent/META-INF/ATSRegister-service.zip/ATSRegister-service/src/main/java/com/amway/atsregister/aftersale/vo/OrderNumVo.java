package com.amway.atsregister.aftersale.vo;

import java.io.Serializable;

public class OrderNumVo implements Serializable {
	private static final long serialVersionUID = -4596173399392877145L;

	private String date;
	private int num;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

}
