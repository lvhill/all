package com.amway.atsregister.common.dao;

import java.util.List;

import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

/**
 * mongo基础dao接口
 * 
 * @author xl,xu
 * 
 */
public interface BaseDao<T> {
	/**
	 * 保存一个实体
	 * 
	 * @param t
	 *            实体
	 */
	public void save(T t);

	/**
	 * 根据ID获取一个实体
	 * 
	 * @param id
	 * @return 实体T
	 */
	public T findObjectById(String id);

	/**
	 * 获取已保存的所有实体
	 * 
	 * @return
	 */
	public List<T> findAll();

	/**
	 * 根据查询条件q 更新 u
	 * 
	 * @param q
	 *            查询条件q
	 * @param u
	 *            根据语句u
	 */
	public void update(Query q, Update u);

	public void updateMulti(Query q, Update u);

	/**
	 * 根据查询条件q删除对应实体
	 * 
	 * @param q
	 */
	public void remove(Query q);

	/**
	 * 保存一个实体
	 * 
	 * @param t
	 */
	public void insert(T t);

	/**
	 * 判断id是否存在
	 * 
	 * @param id
	 * @return
	 */
	public boolean isExist(String id);

	/**
	 * 批量保存
	 * 
	 * @param col
	 */
	public void insertAll(List<T> list);
}
