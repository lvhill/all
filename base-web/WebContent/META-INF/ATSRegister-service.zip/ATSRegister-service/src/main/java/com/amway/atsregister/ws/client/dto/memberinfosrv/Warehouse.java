
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>warehouse complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="warehouse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="city" type="{http://member.facade.service.ebiz.amway.com/}city" minOccurs="0"/>
 *         &lt;element name="ctrAdr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ctrCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ctrNam" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ctyCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dirSaleFlg" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="minDlyAmt" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="regCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "warehouse", propOrder = {
    "city",
    "ctrAdr",
    "ctrCde",
    "ctrNam",
    "ctyCde",
    "dirSaleFlg",
    "minDlyAmt",
    "regCde"
})
public class Warehouse {

    protected City city;
    protected String ctrAdr;
    protected String ctrCde;
    protected String ctrNam;
    protected String ctyCde;
    protected Long dirSaleFlg;
    protected Double minDlyAmt;
    protected String regCde;

    /**
     * 获取city属性的值。
     * 
     * @return
     *     possible object is
     *     {@link City }
     *     
     */
    public City getCity() {
        return city;
    }

    /**
     * 设置city属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link City }
     *     
     */
    public void setCity(City value) {
        this.city = value;
    }

    /**
     * 获取ctrAdr属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrAdr() {
        return ctrAdr;
    }

    /**
     * 设置ctrAdr属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrAdr(String value) {
        this.ctrAdr = value;
    }

    /**
     * 获取ctrCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrCde() {
        return ctrCde;
    }

    /**
     * 设置ctrCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrCde(String value) {
        this.ctrCde = value;
    }

    /**
     * 获取ctrNam属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrNam() {
        return ctrNam;
    }

    /**
     * 设置ctrNam属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrNam(String value) {
        this.ctrNam = value;
    }

    /**
     * 获取ctyCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtyCde() {
        return ctyCde;
    }

    /**
     * 设置ctyCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtyCde(String value) {
        this.ctyCde = value;
    }

    /**
     * 获取dirSaleFlg属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getDirSaleFlg() {
        return dirSaleFlg;
    }

    /**
     * 设置dirSaleFlg属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setDirSaleFlg(Long value) {
        this.dirSaleFlg = value;
    }

    /**
     * 获取minDlyAmt属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMinDlyAmt() {
        return minDlyAmt;
    }

    /**
     * 设置minDlyAmt属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMinDlyAmt(Double value) {
        this.minDlyAmt = value;
    }

    /**
     * 获取regCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegCde() {
        return regCde;
    }

    /**
     * 设置regCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegCde(String value) {
        this.regCde = value;
    }

}
