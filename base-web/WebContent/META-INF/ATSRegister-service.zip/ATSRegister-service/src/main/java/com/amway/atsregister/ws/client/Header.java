package com.amway.atsregister.ws.client;

public class Header
{
	private String osbappid;
	private String osbappkey;

	public String getOsbappid()
	{
		return osbappid;
	}

	public void setOsbappid(String osbappid)
	{
		this.osbappid = osbappid;
	}

	public String getOsbappkey()
	{
		return osbappkey;
	}

	public void setOsbappkey(String osbappkey)
	{
		this.osbappkey = osbappkey;
	}

}
