package com.amway.atsregister.aftersale.dao.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amway.atsregister.aftersale.dao.DistrictCacheDao;
import com.amway.atsregister.aftersale.dao.UserRegistryExtDao;
import com.amway.atsregister.aftersale.dto.UserRegistryExt;
import com.amway.atsregister.aftersale.vo.District;
import com.amway.atsregister.common.dao.impl.BaseDaoImpl;
import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;

@Repository("userRegistryExtDao")
public class UserRegistryExtDaoImpl extends BaseDaoImpl<UserRegistryExt> implements UserRegistryExtDao {

	@Autowired
	private DistrictCacheDao districtCacheDao;

	@Override
	public List<District> getProvList() {
		return districtCacheDao.getProvList();
	}

	@Override
	public List<District> getCitysByProvince(String provCode) {
		return districtCacheDao.getCitysByProvince(provCode);
	}

	@Override
	public List<District> getTownByCity(String cityCode) {
		return districtCacheDao.getTownByCity(cityCode);
	}

	@Override
	public String getMaxOrderNum(Date date) {
		// 执行mongodb聚合查询获取某天最大工单号: db.userRegistryExt.aggregate([{$match:
		// {'orderNum':{$regex:'^A20170418'}}}, {$group:{'_id':
		// null,'orderNum':{$max:'$orderNum'}}}])
		String maxOrderNum = "";
		SimpleDateFormat timeFormat = new SimpleDateFormat("yyyyMMdd");
		String time = timeFormat.format(date);
		String regex = "^A" + time;

		List<DBObject> params = new ArrayList<DBObject>();
		String matchStr = "{$match: {'orderNum':{$regex:'" + regex + "'}}}";
		DBObject match = (DBObject) JSON.parse(matchStr);
		params.add(match);
		String groupStr = "{$group:{'_id': null,'orderNum':{$max:'$orderNum'}}}";
		DBObject group = (DBObject) JSON.parse(groupStr);
		params.add(group);
		AggregationOutput output = mongoTemplate.getCollection("userRegistryExt").aggregate(params);
		for (Iterator<DBObject> it = output.results().iterator(); it.hasNext();) {
			BasicDBObject row = (BasicDBObject) it.next();
			maxOrderNum = (String) row.get("orderNum");
		}
		return maxOrderNum;
	}

}
