package com.amway.atsregister.system;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.jndi.JndiTemplate;

/**
 * jms配置类 Created by abc123 on 17/3/21.
 */
@Configuration
public class JmsConfiguration {
    @Value("${jms.url}")
    private String url;
    @Value("${jms.initial}")
    private String initial;
    //@Value("${jms.username}")
    private String principal;
    //@Value("${jms.password}")
    private String credentials;
    @Value("${jms.connectionFactory}")
    private String connectionFactory;

    /*
     * @Value("${jms.installOrderQueue}") private String installOrderQueue;
     * 
     * @Value("${jms.repairOrderQueue}") private String repairOrderQueue;
     * 
     * @Value("${jms.receivingQueue}") private String receivingQueue;
     * 
     * @Value("${jms.cancelQueue}") private String cancelQueue;
     * 
     * @Value("${jms.repairResultQueue}") private String repairResultQueue;
     * 
     * @Value("${jms.installResultQueue}") private String installResultQueue;
     */

    @Bean
    public JndiTemplate getJndiTemplate() {
        Properties environment = new Properties();
        environment.put("java.naming.provider.url", url);
        environment.put("java.naming.factory.initial", initial);
        //environment.put("java.naming.security.principal", principal);
        //environment.put("java.naming.security.credentials", credentials);
        JndiTemplate j = new JndiTemplate(environment);
        return j;
    }

    @Bean
    public JndiObjectFactoryBean getJndiObjectFactoryBean(JndiTemplate jndiTemplate) {
        JndiObjectFactoryBean j = new JndiObjectFactoryBean();

        j.setJndiName(connectionFactory);
        j.setJndiTemplate(jndiTemplate);
        return j;
    }

    /*
     * @Bean("jmsTempInstallOrder") public JmsTemplate getJmsTempInstallOrder(JndiObjectFactoryBean
     * jndiObjectFactoryBean) throws NamingException { JmsTemplate j = new JmsTemplate();
     * 
     * j.setConnectionFactory((ConnectionFactory) jndiObjectFactoryBean.getObject());
     * 
     * Destination d = (Destination)
     * jndiObjectFactoryBean.getJndiTemplate().lookup(installOrderQueue);
     * j.setDefaultDestination(d);
     * 
     * 
     * j.setMessageConverter(new SimpleMessageConverter());
     * 
     * j.setReceiveTimeout(1L);
     * 
     * return j; }
     */
    /**
     * @Bean("jmsTempRepairOrder") public JmsTemplate getJmsTempRepairOrder(JndiObjectFactoryBean
     *                             jndiObjectFactoryBean) throws NamingException { JmsTemplate j =
     *                             new JmsTemplate();
     *                             j.setConnectionFactory((ConnectionFactory)jndiObjectFactoryBean
     *                             .getObject());
     * 
     * 
     *                             Destination d = (Destination)
     *                             jndiObjectFactoryBean.getJndiTemplate().lookup(repairOrderQueue);
     *                             j.setDefaultDestination(d);
     * 
     * 
     *                             j.setMessageConverter(new SimpleMessageConverter());
     * 
     *                             j.setReceiveTimeout(1L);
     * 
     *                             return j; }
     * 
     * 
     * 
     * @Bean("jmsTempReceiving") public JmsTemplate getJmsTempReceiving(JndiObjectFactoryBean
     *                           jndiObjectFactoryBean) throws NamingException { JmsTemplate j = new
     *                           JmsTemplate();
     *                           j.setConnectionFactory((ConnectionFactory)jndiObjectFactoryBean
     *                           .getObject());
     * 
     * 
     * 
     *                           Destination d = (Destination)
     *                           jndiObjectFactoryBean.getJndiTemplate().lookup(receivingQueue);
     *                           j.setDefaultDestination(d);
     * 
     * 
     *                           j.setMessageConverter(new SimpleMessageConverter());
     * 
     *                           j.setReceiveTimeout(1L);
     * 
     *                           return j; }
     * 
     * 
     * 
     * @Bean("jmsTempCancelOrder") public JmsTemplate getJmsTempCancelOrder(JndiObjectFactoryBean
     *                             jndiObjectFactoryBean) throws NamingException { JmsTemplate j =
     *                             new JmsTemplate();
     *                             j.setConnectionFactory((ConnectionFactory)jndiObjectFactoryBean
     *                             .getObject());
     * 
     *                             Destination d = (Destination)
     *                             jndiObjectFactoryBean.getJndiTemplate().lookup(cancelQueue);
     *                             j.setDefaultDestination(d);
     * 
     *                             j.setMessageConverter(new SimpleMessageConverter());
     * 
     *                             j.setReceiveTimeout(1L);
     * 
     *                             return j; }
     * 
     * 
     * @Bean("jmsTempInstallResult") public JmsTemplate
     *                               getJmsTempInstallResult(JndiObjectFactoryBean
     *                               jndiObjectFactoryBean) throws NamingException { JmsTemplate j =
     *                               new JmsTemplate();
     *                               j.setConnectionFactory((ConnectionFactory)jndiObjectFactoryBean
     *                               .getObject());
     * 
     * 
     * 
     *                               Destination d = (Destination)
     *                               jndiObjectFactoryBean.getJndiTemplate
     *                               ().lookup(installResultQueue); j.setDefaultDestination(d);
     * 
     * 
     * 
     *                               j.setMessageConverter(new SimpleMessageConverter());
     * 
     *                               j.setReceiveTimeout(1L);
     * 
     *                               return j; }
     */
    /**
     * 维修单结果
     * 
     * @param
     * @return
     */
    /*
     * @Bean("jmsTempRepairResult") public JmsTemplate getJmsTempRepairResult(JndiObjectFactoryBean
     * jndiObjectFactoryBean) throws NamingException { JmsTemplate j = new JmsTemplate();
     * j.setConnectionFactory((ConnectionFactory)jndiObjectFactoryBean.getObject ());
     * 
     * 
     * 
     * Destination d = (Destination)
     * jndiObjectFactoryBean.getJndiTemplate().lookup(repairResultQueue);
     * j.setDefaultDestination(d);
     * 
     * 
     * 
     * j.setMessageConverter(new SimpleMessageConverter());
     * 
     * j.setReceiveTimeout(1L);
     * 
     * return j; }
     */

}
