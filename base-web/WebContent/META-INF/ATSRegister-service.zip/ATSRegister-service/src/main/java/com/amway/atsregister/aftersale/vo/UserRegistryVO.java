/**
 * 文件名：UserRegistry 描述：用户注册model 创建时间：2012/3/30 作者： big pig
 */
package com.amway.atsregister.aftersale.vo;

import java.io.Serializable;
import java.util.List;

/**
 * 类功能描述：用户注册model
 * 
 * @author ligaofu
 * @date 2012/3/30
 * @version 1.0
 */
public class UserRegistryVO implements Serializable {
    private static final long serialVersionUID = 2959336891858181030L;

    /** 用户姓名 */
    private String customerName;
    /** 产品使用省 */
    private String customerRealProv;
    private String customerRealProvStr;
    /** 产品使用城市 */
    private String customerRealCity;
    private String customerRealCityStr;
    /** 使用者区县 */
    private String customerTown;
    private String customerTownStr;
    /** 产品使用地址 */
    private String customerRealAddr;
    /** 使用者手机号 */
    private String customerTel;
    /** 使用者电话 */
    private String customerPhone;
    /** 使用者email */
    private String customerEmail;
    /** 机器信息列表 */
    private List<Machine> machineList;
    /** 上门服务时间：1:工作日，2:周末，3:工作日周末皆可 */
    private Integer homeServiceTime;
    /** 您是否是安利销售代表、经销商或优惠顾客：0:否，1:是 */
    private Integer isCustomer;
    /** 使用者安利卡号 */
    private String userAdano;
    /** 营销人员的姓名 */
    private String serviceStaffName;
    /** 营销人员的联系方式 */
    private String serviceStaffContact;
    /** 是否同意条款：0:否，1:是 */
    private Integer isAgreeArticle;
    /** 验证码 */
    private String randomCode;

    public String getUserAdano() {
        return userAdano;
    }

    public void setUserAdano(String userAdano) {
        this.userAdano = userAdano;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public String getCustomerTel() {
        return customerTel;
    }

    public void setCustomerTel(String customerTel) {
        this.customerTel = customerTel;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public String getCustomerRealProv() {
        return customerRealProv;
    }

    public void setCustomerRealProv(String customerRealProv) {
        this.customerRealProv = customerRealProv;
    }

    public String getCustomerRealProvStr() {
        return customerRealProvStr;
    }

    public void setCustomerRealProvStr(String customerRealProvStr) {
        this.customerRealProvStr = customerRealProvStr;
    }

    public String getCustomerRealCity() {
        return customerRealCity;
    }

    public void setCustomerRealCity(String customerRealCity) {
        this.customerRealCity = customerRealCity;
    }

    public String getCustomerRealCityStr() {
        return customerRealCityStr;
    }

    public void setCustomerRealCityStr(String customerRealCityStr) {
        this.customerRealCityStr = customerRealCityStr;
    }

    public String getCustomerTown() {
        return customerTown;
    }

    public void setCustomerTown(String customerTown) {
        this.customerTown = customerTown;
    }

    public String getCustomerTownStr() {
        return customerTownStr;
    }

    public void setCustomerTownStr(String customerTownStr) {
        this.customerTownStr = customerTownStr;
    }

    public String getCustomerRealAddr() {
        return customerRealAddr;
    }

    public void setCustomerRealAddr(String customerRealAddr) {
        this.customerRealAddr = customerRealAddr;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Integer getIsCustomer() {
        return isCustomer;
    }

    public void setIsCustomer(Integer isCustomer) {
        this.isCustomer = isCustomer;
    }

    public Integer getIsAgreeArticle() {
        return isAgreeArticle;
    }

    public void setIsAgreeArticle(Integer isAgreeArticle) {
        this.isAgreeArticle = isAgreeArticle;
    }

    public Integer getHomeServiceTime() {
        return homeServiceTime;
    }

    public void setHomeServiceTime(Integer homeServiceTime) {
        this.homeServiceTime = homeServiceTime;
    }

    public String getServiceStaffName() {
        return serviceStaffName;
    }

    public void setServiceStaffName(String serviceStaffName) {
        this.serviceStaffName = serviceStaffName;
    }

    public String getServiceStaffContact() {
        return serviceStaffContact;
    }

    public void setServiceStaffContact(String serviceStaffContact) {
        this.serviceStaffContact = serviceStaffContact;
    }

    public List<Machine> getMachineList() {
        return machineList;
    }

    public void setMachineList(List<Machine> machineList) {
        this.machineList = machineList;
    }

    public String getRandomCode() {
        return randomCode;
    }

    public void setRandomCode(String randomCode) {
        this.randomCode = randomCode;
    }

}
