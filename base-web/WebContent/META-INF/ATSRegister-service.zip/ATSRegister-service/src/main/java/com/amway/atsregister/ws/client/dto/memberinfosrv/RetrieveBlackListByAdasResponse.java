
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>retrieveBlackListByAdasResponse complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="retrieveBlackListByAdasResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="blackListDO" type="{http://member.facade.service.ebiz.amway.com/}blackListDO" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveBlackListByAdasResponse", propOrder = {
    "blackListDO"
})
public class RetrieveBlackListByAdasResponse {

    protected BlackListDO blackListDO;

    /**
     * 获取blackListDO属性的值。
     * 
     * @return
     *     possible object is
     *     {@link BlackListDO }
     *     
     */
    public BlackListDO getBlackListDO() {
        return blackListDO;
    }

    /**
     * 设置blackListDO属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link BlackListDO }
     *     
     */
    public void setBlackListDO(BlackListDO value) {
        this.blackListDO = value;
    }

}
