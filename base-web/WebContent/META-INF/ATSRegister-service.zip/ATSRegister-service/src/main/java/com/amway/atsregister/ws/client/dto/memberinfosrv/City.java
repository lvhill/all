
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>city complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="city">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ctyCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ctyNam" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ctyNamEng" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="prvCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="prvNam" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "city", propOrder = {
    "ctyCde",
    "ctyNam",
    "ctyNamEng",
    "prvCde",
    "prvNam"
})
public class City {

    protected String ctyCde;
    protected String ctyNam;
    protected String ctyNamEng;
    protected String prvCde;
    protected String prvNam;

    /**
     * 获取ctyCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtyCde() {
        return ctyCde;
    }

    /**
     * 设置ctyCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtyCde(String value) {
        this.ctyCde = value;
    }

    /**
     * 获取ctyNam属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtyNam() {
        return ctyNam;
    }

    /**
     * 设置ctyNam属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtyNam(String value) {
        this.ctyNam = value;
    }

    /**
     * 获取ctyNamEng属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtyNamEng() {
        return ctyNamEng;
    }

    /**
     * 设置ctyNamEng属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtyNamEng(String value) {
        this.ctyNamEng = value;
    }

    /**
     * 获取prvCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrvCde() {
        return prvCde;
    }

    /**
     * 设置prvCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrvCde(String value) {
        this.prvCde = value;
    }

    /**
     * 获取prvNam属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrvNam() {
        return prvNam;
    }

    /**
     * 设置prvNam属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrvNam(String value) {
        this.prvNam = value;
    }

}
