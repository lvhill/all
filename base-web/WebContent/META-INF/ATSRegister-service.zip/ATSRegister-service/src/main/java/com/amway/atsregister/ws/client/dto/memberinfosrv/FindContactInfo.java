
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>findContactInfo complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="findContactInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="contactInfoSO" type="{http://member.facade.service.ebiz.amway.com/}contactInfoSO" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "findContactInfo", propOrder = {
    "contactInfoSO"
})
public class FindContactInfo {

    protected ContactInfoSO contactInfoSO;

    /**
     * 获取contactInfoSO属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoSO }
     *     
     */
    public ContactInfoSO getContactInfoSO() {
        return contactInfoSO;
    }

    /**
     * 设置contactInfoSO属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoSO }
     *     
     */
    public void setContactInfoSO(ContactInfoSO value) {
        this.contactInfoSO = value;
    }

}
