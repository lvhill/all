
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>aicmaincBO complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="aicmaincBO">
 *   &lt;complexContent>
 *     &lt;extension base="{http://member.facade.service.ebiz.amway.com/}inquiryObject">
 *       &lt;sequence>
 *         &lt;element name="actual" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="aicSqe" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="aicTemplate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="applyMth" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="applyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="disNum" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="letheader" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="payNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="postCost" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="postType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="postWays" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="pscNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rcAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rcName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rcPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rcPostalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rfNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rsv1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rsv2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sendFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="updateDate" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="updateTime" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="updateUser" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "aicmaincBO", propOrder = {
    "actual",
    "aicSqe",
    "aicTemplate",
    "applyMth",
    "applyName",
    "disNum",
    "id",
    "letheader",
    "mstName",
    "payNum",
    "postCost",
    "postType",
    "postWays",
    "pscNum",
    "rcAddress",
    "rcName",
    "rcPhone",
    "rcPostalCode",
    "rfNum",
    "rsv1",
    "rsv2",
    "sendFlag",
    "updateDate",
    "updateTime",
    "updateUser"
})
public class AicmaincBO
    extends InquiryObject
{

    protected BigDecimal actual;
    protected String aicSqe;
    protected String aicTemplate;
    protected Integer applyMth;
    protected String applyName;
    protected Long disNum;
    protected Long id;
    protected String letheader;
    protected String mstName;
    protected String payNum;
    protected BigDecimal postCost;
    protected String postType;
    protected String postWays;
    protected String pscNum;
    protected String rcAddress;
    protected String rcName;
    protected String rcPhone;
    protected String rcPostalCode;
    protected String rfNum;
    protected String rsv1;
    protected String rsv2;
    protected String sendFlag;
    protected Integer updateDate;
    protected Integer updateTime;
    protected String updateUser;

    /**
     * 获取actual属性的值。
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getActual() {
        return actual;
    }

    /**
     * 设置actual属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setActual(BigDecimal value) {
        this.actual = value;
    }

    /**
     * 获取aicSqe属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAicSqe() {
        return aicSqe;
    }

    /**
     * 设置aicSqe属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAicSqe(String value) {
        this.aicSqe = value;
    }

    /**
     * 获取aicTemplate属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAicTemplate() {
        return aicTemplate;
    }

    /**
     * 设置aicTemplate属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAicTemplate(String value) {
        this.aicTemplate = value;
    }

    /**
     * 获取applyMth属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getApplyMth() {
        return applyMth;
    }

    /**
     * 设置applyMth属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setApplyMth(Integer value) {
        this.applyMth = value;
    }

    /**
     * 获取applyName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplyName() {
        return applyName;
    }

    /**
     * 设置applyName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplyName(String value) {
        this.applyName = value;
    }

    /**
     * 获取disNum属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getDisNum() {
        return disNum;
    }

    /**
     * 设置disNum属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setDisNum(Long value) {
        this.disNum = value;
    }

    /**
     * 获取id属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置id属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setId(Long value) {
        this.id = value;
    }

    /**
     * 获取letheader属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLetheader() {
        return letheader;
    }

    /**
     * 设置letheader属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLetheader(String value) {
        this.letheader = value;
    }

    /**
     * 获取mstName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMstName() {
        return mstName;
    }

    /**
     * 设置mstName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMstName(String value) {
        this.mstName = value;
    }

    /**
     * 获取payNum属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayNum() {
        return payNum;
    }

    /**
     * 设置payNum属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayNum(String value) {
        this.payNum = value;
    }

    /**
     * 获取postCost属性的值。
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPostCost() {
        return postCost;
    }

    /**
     * 设置postCost属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPostCost(BigDecimal value) {
        this.postCost = value;
    }

    /**
     * 获取postType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostType() {
        return postType;
    }

    /**
     * 设置postType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostType(String value) {
        this.postType = value;
    }

    /**
     * 获取postWays属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostWays() {
        return postWays;
    }

    /**
     * 设置postWays属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostWays(String value) {
        this.postWays = value;
    }

    /**
     * 获取pscNum属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPscNum() {
        return pscNum;
    }

    /**
     * 设置pscNum属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPscNum(String value) {
        this.pscNum = value;
    }

    /**
     * 获取rcAddress属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcAddress() {
        return rcAddress;
    }

    /**
     * 设置rcAddress属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcAddress(String value) {
        this.rcAddress = value;
    }

    /**
     * 获取rcName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcName() {
        return rcName;
    }

    /**
     * 设置rcName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcName(String value) {
        this.rcName = value;
    }

    /**
     * 获取rcPhone属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcPhone() {
        return rcPhone;
    }

    /**
     * 设置rcPhone属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcPhone(String value) {
        this.rcPhone = value;
    }

    /**
     * 获取rcPostalCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcPostalCode() {
        return rcPostalCode;
    }

    /**
     * 设置rcPostalCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcPostalCode(String value) {
        this.rcPostalCode = value;
    }

    /**
     * 获取rfNum属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRfNum() {
        return rfNum;
    }

    /**
     * 设置rfNum属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRfNum(String value) {
        this.rfNum = value;
    }

    /**
     * 获取rsv1属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRsv1() {
        return rsv1;
    }

    /**
     * 设置rsv1属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRsv1(String value) {
        this.rsv1 = value;
    }

    /**
     * 获取rsv2属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRsv2() {
        return rsv2;
    }

    /**
     * 设置rsv2属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRsv2(String value) {
        this.rsv2 = value;
    }

    /**
     * 获取sendFlag属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFlag() {
        return sendFlag;
    }

    /**
     * 设置sendFlag属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFlag(String value) {
        this.sendFlag = value;
    }

    /**
     * 获取updateDate属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getUpdateDate() {
        return updateDate;
    }

    /**
     * 设置updateDate属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setUpdateDate(Integer value) {
        this.updateDate = value;
    }

    /**
     * 获取updateTime属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getUpdateTime() {
        return updateTime;
    }

    /**
     * 设置updateTime属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setUpdateTime(Integer value) {
        this.updateTime = value;
    }

    /**
     * 获取updateUser属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdateUser() {
        return updateUser;
    }

    /**
     * 设置updateUser属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdateUser(String value) {
        this.updateUser = value;
    }

}
