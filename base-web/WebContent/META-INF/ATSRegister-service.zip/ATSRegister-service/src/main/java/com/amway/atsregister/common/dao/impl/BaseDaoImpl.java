package com.amway.atsregister.common.dao.impl;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.amway.atsregister.common.dao.BaseDao;

/**
 * mongo基础DAO实现类
 * 
 * @author xl,xu
 * 
 */
@Repository("baseDao")
public class BaseDaoImpl<T> implements BaseDao<T> {
    private Class<T> clazz;

    @Autowired
    protected MongoTemplate mongoTemplate;

    @SuppressWarnings({"rawtypes", "unchecked"})
    public BaseDaoImpl() {
        // 使用反射技术得到T的真实类型
        Class c = getClass();
        Type t = c.getGenericSuperclass();
        if (t instanceof ParameterizedType) {
            this.clazz = (Class<T>) ((ParameterizedType) t).getActualTypeArguments()[0];
        }
    }

    @Override
    public void save(T t) {
        mongoTemplate.save(t);
    }

    @Override
    public void insert(T t) {
        mongoTemplate.save(t);
    }

    @Override
    public T findObjectById(String id) {
        return (T) mongoTemplate.findOne(new Query(new Criteria("id").is(id)), clazz);
    }

    @Override
    public void update(Query q, Update u) {
        mongoTemplate.updateFirst(q, u, clazz);
    }

    @Override
    public void updateMulti(Query q, Update u) {
        mongoTemplate.updateMulti(q, u, clazz);
    }

    @Override
    public void remove(Query q) {
        mongoTemplate.remove(q, clazz);

    }

    public MongoTemplate getMongoTemplate() {
        return mongoTemplate;
    }

    public void setMongoTemplate(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    @Override
    public boolean isExist(String id) {
        return mongoTemplate.exists(new Query(new Criteria("id").is(id)), clazz);
    }

    @Override
    public List<T> findAll() {
        return mongoTemplate.findAll(clazz);
    }
    
    @Override
    public void insertAll(List<T> list){
    	mongoTemplate.insertAll(list);
    }

}
