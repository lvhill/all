
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>inquiryObject complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="inquiryObject">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="returnCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "inquiryObject", propOrder = {
    "returnCode"
})
@XmlSeeAlso({
    CustomerData.class,
    MemberByPageData.class,
    MemberChangeHisData.class,
    ContactInfoDTO.class,
    OneYearActivityDO.class,
    WarehouseTypeDO.class,
    BlackListData.class,
    BankAcc.class,
    MemberHistoryDO.class,
    Member.class,
    LoginInfoDO.class,
    LongContractDO.class,
    AicmaincBO.class,
    WarehouseDO.class,
    MemberSOData.class,
    UserBuyInfoDO.class,
    RecommendationDO.class,
    BankSupplementDO.class,
    AicmaincDO.class,
    PhoneNumberDO.class,
    FindMemberInfoDatas.class,
    MemberListData.class,
    FindMemberInfoData.class,
    CustomerListData.class,
    BlackListDO.class
})
public class InquiryObject {

    protected String returnCode;

    /**
     * 获取returnCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReturnCode() {
        return returnCode;
    }

    /**
     * 设置returnCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReturnCode(String value) {
        this.returnCode = value;
    }

}
