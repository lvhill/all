
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>person complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="person">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="birthday" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="chiNam" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="eduTypCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="engNam" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idcardNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="namTyp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sex" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "person", propOrder = {
    "birthday",
    "chiNam",
    "eduTypCde",
    "engNam",
    "idcardNum",
    "namTyp",
    "sex"
})
public class Person {

    protected int birthday;
    protected String chiNam;
    protected String eduTypCde;
    protected String engNam;
    protected String idcardNum;
    protected String namTyp;
    protected String sex;

    /**
     * 获取birthday属性的值。
     * 
     */
    public int getBirthday() {
        return birthday;
    }

    /**
     * 设置birthday属性的值。
     * 
     */
    public void setBirthday(int value) {
        this.birthday = value;
    }

    /**
     * 获取chiNam属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChiNam() {
        return chiNam;
    }

    /**
     * 设置chiNam属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChiNam(String value) {
        this.chiNam = value;
    }

    /**
     * 获取eduTypCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEduTypCde() {
        return eduTypCde;
    }

    /**
     * 设置eduTypCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEduTypCde(String value) {
        this.eduTypCde = value;
    }

    /**
     * 获取engNam属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEngNam() {
        return engNam;
    }

    /**
     * 设置engNam属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEngNam(String value) {
        this.engNam = value;
    }

    /**
     * 获取idcardNum属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdcardNum() {
        return idcardNum;
    }

    /**
     * 设置idcardNum属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdcardNum(String value) {
        this.idcardNum = value;
    }

    /**
     * 获取namTyp属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNamTyp() {
        return namTyp;
    }

    /**
     * 设置namTyp属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNamTyp(String value) {
        this.namTyp = value;
    }

    /**
     * 获取sex属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSex() {
        return sex;
    }

    /**
     * 设置sex属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSex(String value) {
        this.sex = value;
    }

}
