
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.amway.atsregister.ws.client.dto.memberinfosrv package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _IsSRInShopSale_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "isSRInShopSale");
    private final static QName _RetrieveCustomerListResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "retrieveCustomerListResponse");
    private final static QName _ChangeNewApplyStatus_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "changeNewApplyStatus");
    private final static QName _RetrieveMember_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "retrieveMember");
    private final static QName _GetAicmaincInfoBySendFlagResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "getAicmaincInfoBySendFlagResponse");
    private final static QName _RetrieveOneYearActivityInfo_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "retrieveOneYearActivityInfo");
    private final static QName _LoginForIVR_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "loginForIVR");
    private final static QName _QueryBankSupplement_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryBankSupplement");
    private final static QName _BankSupplement_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "bankSupplement");
    private final static QName _QueryBankAcc_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryBankAcc");
    private final static QName _ChangeNewApplyStatusResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "changeNewApplyStatusResponse");
    private final static QName _UpdateSDISProcess_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "updateSDISProcess");
    private final static QName _GetMemberSimpleInfoResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "getMemberSimpleInfoResponse");
    private final static QName _QueryUnderlingABOResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryUnderlingABOResponse");
    private final static QName _SignLongContractResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "signLongContractResponse");
    private final static QName _QueryLongContractResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryLongContractResponse");
    private final static QName _RetrieveMemberList_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "retrieveMemberList");
    private final static QName _SaveContactInfo_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "saveContactInfo");
    private final static QName _GetAicmaincInfoBySendFlag_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "getAicmaincInfoBySendFlag");
    private final static QName _RetrieveMemberChangeHisResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "retrieveMemberChangeHisResponse");
    private final static QName _CanSignLongContractResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "canSignLongContractResponse");
    private final static QName _IsNewMemberResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "isNewMemberResponse");
    private final static QName _QueryLongContract_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryLongContract");
    private final static QName _SaveContactInfoResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "saveContactInfoResponse");
    private final static QName _ReActiveMemberForPosRenewalResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "reActiveMemberForPosRenewalResponse");
    private final static QName _FindContactInfoResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "findContactInfoResponse");
    private final static QName _UpdateLongContractArchiveResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "updateLongContractArchiveResponse");
    private final static QName _Exception_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "Exception");
    private final static QName _GetAicmaincInfoResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "getAicmaincInfoResponse");
    private final static QName _IfRecommendationRight_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "ifRecommendationRight");
    private final static QName _IsDDAndUp_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "isDDAndUp");
    private final static QName _IsNewMember_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "isNewMember");
    private final static QName _RetrieveUserBuyInfo_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "retrieveUserBuyInfo");
    private final static QName _CanSignLongContract_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "canSignLongContract");
    private final static QName _QueryLongContractByStatus_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryLongContractByStatus");
    private final static QName _IsAdaValidResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "isAdaValidResponse");
    private final static QName _LoginForIVRResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "loginForIVRResponse");
    private final static QName _UpdateAicmaincSendStateResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "updateAicmaincSendStateResponse");
    private final static QName _UpdateLongContractArchive_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "updateLongContractArchive");
    private final static QName _QueryUnderlingABO_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryUnderlingABO");
    private final static QName _IfRecommendationRightResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "ifRecommendationRightResponse");
    private final static QName _QueryAAInfoResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryAAInfoResponse");
    private final static QName _QueryBankAccResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryBankAccResponse");
    private final static QName _IsSRInShopSaleResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "isSRInShopSaleResponse");
    private final static QName _RetrieveMemberChangeHis_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "retrieveMemberChangeHis");
    private final static QName _UpdateAicmaincSendStateById_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "updateAicmaincSendStateById");
    private final static QName _FindMemberInfoResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "findMemberInfoResponse");
    private final static QName _UpdateAicmaincSendStateByIdResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "updateAicmaincSendStateByIdResponse");
    private final static QName _QueryAAInfo_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryAAInfo");
    private final static QName _QueryBankSupplementByStatusResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryBankSupplementByStatusResponse");
    private final static QName _RetrieveMemberResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "retrieveMemberResponse");
    private final static QName _RetrieveMemberListResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "retrieveMemberListResponse");
    private final static QName _GetMemberContactInfoResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "getMemberContactInfoResponse");
    private final static QName _IsDDAndUpResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "isDDAndUpResponse");
    private final static QName _SignLongContract_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "signLongContract");
    private final static QName _IsSPAndUpResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "isSPAndUpResponse");
    private final static QName _ChangePasswordForIVRResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "changePasswordForIVRResponse");
    private final static QName _GetAicmaincInfo_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "getAicmaincInfo");
    private final static QName _GetMemberHistoryResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "getMemberHistoryResponse");
    private final static QName _RetrieveBlackListByAdas_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "retrieveBlackListByAdas");
    private final static QName _FindContactInfo_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "findContactInfo");
    private final static QName _GetMemberHistory_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "getMemberHistory");
    private final static QName _BankSupplementResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "bankSupplementResponse");
    private final static QName _QueryRecommendationResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryRecommendationResponse");
    private final static QName _IsAdaValid_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "isAdaValid");
    private final static QName _QueryBankSupplementResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryBankSupplementResponse");
    private final static QName _FindMemberInfo_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "findMemberInfo");
    private final static QName _IsSPAndUp_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "isSPAndUp");
    private final static QName _UpdateSDISProcessResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "updateSDISProcessResponse");
    private final static QName _ReActiveMemberForPosRenewal_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "reActiveMemberForPosRenewal");
    private final static QName _RetrieveOneYearActivityInfoResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "retrieveOneYearActivityInfoResponse");
    private final static QName _QueryLongContractByStatusResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryLongContractByStatusResponse");
    private final static QName _QueryRecommendation_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryRecommendation");
    private final static QName _RetrieveBlackListByAdasResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "retrieveBlackListByAdasResponse");
    private final static QName _RetrieveUserBuyInfoResponse_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "retrieveUserBuyInfoResponse");
    private final static QName _GetMemberSimpleInfo_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "getMemberSimpleInfo");
    private final static QName _RetrieveCustomerList_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "retrieveCustomerList");
    private final static QName _GetMemberContactInfo_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "getMemberContactInfo");
    private final static QName _QueryBankSupplementByStatus_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "queryBankSupplementByStatus");
    private final static QName _ChangePasswordForIVR_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "changePasswordForIVR");
    private final static QName _UpdateAicmaincSendState_QNAME = new QName("http://member.facade.service.ebiz.amway.com/", "updateAicmaincSendState");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.amway.atsregister.ws.client.dto.memberinfosrv
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link LoginForIVRResponse }
     * 
     */
    public LoginForIVRResponse createLoginForIVRResponse() {
        return new LoginForIVRResponse();
    }

    /**
     * Create an instance of {@link IsAdaValidResponse }
     * 
     */
    public IsAdaValidResponse createIsAdaValidResponse() {
        return new IsAdaValidResponse();
    }

    /**
     * Create an instance of {@link QueryUnderlingABO }
     * 
     */
    public QueryUnderlingABO createQueryUnderlingABO() {
        return new QueryUnderlingABO();
    }

    /**
     * Create an instance of {@link UpdateAicmaincSendStateResponse }
     * 
     */
    public UpdateAicmaincSendStateResponse createUpdateAicmaincSendStateResponse() {
        return new UpdateAicmaincSendStateResponse();
    }

    /**
     * Create an instance of {@link UpdateLongContractArchive }
     * 
     */
    public UpdateLongContractArchive createUpdateLongContractArchive() {
        return new UpdateLongContractArchive();
    }

    /**
     * Create an instance of {@link IfRecommendationRightResponse }
     * 
     */
    public IfRecommendationRightResponse createIfRecommendationRightResponse() {
        return new IfRecommendationRightResponse();
    }

    /**
     * Create an instance of {@link QueryAAInfoResponse }
     * 
     */
    public QueryAAInfoResponse createQueryAAInfoResponse() {
        return new QueryAAInfoResponse();
    }

    /**
     * Create an instance of {@link QueryBankAccResponse }
     * 
     */
    public QueryBankAccResponse createQueryBankAccResponse() {
        return new QueryBankAccResponse();
    }

    /**
     * Create an instance of {@link FindMemberInfoResponse }
     * 
     */
    public FindMemberInfoResponse createFindMemberInfoResponse() {
        return new FindMemberInfoResponse();
    }

    /**
     * Create an instance of {@link UpdateAicmaincSendStateByIdResponse }
     * 
     */
    public UpdateAicmaincSendStateByIdResponse createUpdateAicmaincSendStateByIdResponse() {
        return new UpdateAicmaincSendStateByIdResponse();
    }

    /**
     * Create an instance of {@link IsSRInShopSaleResponse }
     * 
     */
    public IsSRInShopSaleResponse createIsSRInShopSaleResponse() {
        return new IsSRInShopSaleResponse();
    }

    /**
     * Create an instance of {@link RetrieveMemberChangeHis }
     * 
     */
    public RetrieveMemberChangeHis createRetrieveMemberChangeHis() {
        return new RetrieveMemberChangeHis();
    }

    /**
     * Create an instance of {@link UpdateAicmaincSendStateById }
     * 
     */
    public UpdateAicmaincSendStateById createUpdateAicmaincSendStateById() {
        return new UpdateAicmaincSendStateById();
    }

    /**
     * Create an instance of {@link QueryBankSupplementByStatusResponse }
     * 
     */
    public QueryBankSupplementByStatusResponse createQueryBankSupplementByStatusResponse() {
        return new QueryBankSupplementByStatusResponse();
    }

    /**
     * Create an instance of {@link RetrieveMemberResponse }
     * 
     */
    public RetrieveMemberResponse createRetrieveMemberResponse() {
        return new RetrieveMemberResponse();
    }

    /**
     * Create an instance of {@link QueryAAInfo }
     * 
     */
    public QueryAAInfo createQueryAAInfo() {
        return new QueryAAInfo();
    }

    /**
     * Create an instance of {@link RetrieveMemberListResponse }
     * 
     */
    public RetrieveMemberListResponse createRetrieveMemberListResponse() {
        return new RetrieveMemberListResponse();
    }

    /**
     * Create an instance of {@link GetMemberContactInfoResponse }
     * 
     */
    public GetMemberContactInfoResponse createGetMemberContactInfoResponse() {
        return new GetMemberContactInfoResponse();
    }

    /**
     * Create an instance of {@link SignLongContract }
     * 
     */
    public SignLongContract createSignLongContract() {
        return new SignLongContract();
    }

    /**
     * Create an instance of {@link IsDDAndUpResponse }
     * 
     */
    public IsDDAndUpResponse createIsDDAndUpResponse() {
        return new IsDDAndUpResponse();
    }

    /**
     * Create an instance of {@link IsSPAndUpResponse }
     * 
     */
    public IsSPAndUpResponse createIsSPAndUpResponse() {
        return new IsSPAndUpResponse();
    }

    /**
     * Create an instance of {@link GetMemberHistoryResponse }
     * 
     */
    public GetMemberHistoryResponse createGetMemberHistoryResponse() {
        return new GetMemberHistoryResponse();
    }

    /**
     * Create an instance of {@link ChangePasswordForIVRResponse }
     * 
     */
    public ChangePasswordForIVRResponse createChangePasswordForIVRResponse() {
        return new ChangePasswordForIVRResponse();
    }

    /**
     * Create an instance of {@link GetAicmaincInfo }
     * 
     */
    public GetAicmaincInfo createGetAicmaincInfo() {
        return new GetAicmaincInfo();
    }

    /**
     * Create an instance of {@link RetrieveBlackListByAdas }
     * 
     */
    public RetrieveBlackListByAdas createRetrieveBlackListByAdas() {
        return new RetrieveBlackListByAdas();
    }

    /**
     * Create an instance of {@link BankSupplementResponse }
     * 
     */
    public BankSupplementResponse createBankSupplementResponse() {
        return new BankSupplementResponse();
    }

    /**
     * Create an instance of {@link QueryRecommendationResponse }
     * 
     */
    public QueryRecommendationResponse createQueryRecommendationResponse() {
        return new QueryRecommendationResponse();
    }

    /**
     * Create an instance of {@link FindContactInfo }
     * 
     */
    public FindContactInfo createFindContactInfo() {
        return new FindContactInfo();
    }

    /**
     * Create an instance of {@link GetMemberHistory }
     * 
     */
    public GetMemberHistory createGetMemberHistory() {
        return new GetMemberHistory();
    }

    /**
     * Create an instance of {@link IsAdaValid }
     * 
     */
    public IsAdaValid createIsAdaValid() {
        return new IsAdaValid();
    }

    /**
     * Create an instance of {@link QueryBankSupplementResponse }
     * 
     */
    public QueryBankSupplementResponse createQueryBankSupplementResponse() {
        return new QueryBankSupplementResponse();
    }

    /**
     * Create an instance of {@link FindMemberInfo }
     * 
     */
    public FindMemberInfo createFindMemberInfo() {
        return new FindMemberInfo();
    }

    /**
     * Create an instance of {@link IsSPAndUp }
     * 
     */
    public IsSPAndUp createIsSPAndUp() {
        return new IsSPAndUp();
    }

    /**
     * Create an instance of {@link UpdateSDISProcessResponse }
     * 
     */
    public UpdateSDISProcessResponse createUpdateSDISProcessResponse() {
        return new UpdateSDISProcessResponse();
    }

    /**
     * Create an instance of {@link ReActiveMemberForPosRenewal }
     * 
     */
    public ReActiveMemberForPosRenewal createReActiveMemberForPosRenewal() {
        return new ReActiveMemberForPosRenewal();
    }

    /**
     * Create an instance of {@link RetrieveOneYearActivityInfoResponse }
     * 
     */
    public RetrieveOneYearActivityInfoResponse createRetrieveOneYearActivityInfoResponse() {
        return new RetrieveOneYearActivityInfoResponse();
    }

    /**
     * Create an instance of {@link QueryLongContractByStatusResponse }
     * 
     */
    public QueryLongContractByStatusResponse createQueryLongContractByStatusResponse() {
        return new QueryLongContractByStatusResponse();
    }

    /**
     * Create an instance of {@link QueryRecommendation }
     * 
     */
    public QueryRecommendation createQueryRecommendation() {
        return new QueryRecommendation();
    }

    /**
     * Create an instance of {@link RetrieveBlackListByAdasResponse }
     * 
     */
    public RetrieveBlackListByAdasResponse createRetrieveBlackListByAdasResponse() {
        return new RetrieveBlackListByAdasResponse();
    }

    /**
     * Create an instance of {@link RetrieveUserBuyInfoResponse }
     * 
     */
    public RetrieveUserBuyInfoResponse createRetrieveUserBuyInfoResponse() {
        return new RetrieveUserBuyInfoResponse();
    }

    /**
     * Create an instance of {@link GetMemberSimpleInfo }
     * 
     */
    public GetMemberSimpleInfo createGetMemberSimpleInfo() {
        return new GetMemberSimpleInfo();
    }

    /**
     * Create an instance of {@link RetrieveCustomerList }
     * 
     */
    public RetrieveCustomerList createRetrieveCustomerList() {
        return new RetrieveCustomerList();
    }

    /**
     * Create an instance of {@link GetMemberContactInfo }
     * 
     */
    public GetMemberContactInfo createGetMemberContactInfo() {
        return new GetMemberContactInfo();
    }

    /**
     * Create an instance of {@link QueryBankSupplementByStatus }
     * 
     */
    public QueryBankSupplementByStatus createQueryBankSupplementByStatus() {
        return new QueryBankSupplementByStatus();
    }

    /**
     * Create an instance of {@link ChangePasswordForIVR }
     * 
     */
    public ChangePasswordForIVR createChangePasswordForIVR() {
        return new ChangePasswordForIVR();
    }

    /**
     * Create an instance of {@link UpdateAicmaincSendState }
     * 
     */
    public UpdateAicmaincSendState createUpdateAicmaincSendState() {
        return new UpdateAicmaincSendState();
    }

    /**
     * Create an instance of {@link IsSRInShopSale }
     * 
     */
    public IsSRInShopSale createIsSRInShopSale() {
        return new IsSRInShopSale();
    }

    /**
     * Create an instance of {@link ChangeNewApplyStatus }
     * 
     */
    public ChangeNewApplyStatus createChangeNewApplyStatus() {
        return new ChangeNewApplyStatus();
    }

    /**
     * Create an instance of {@link RetrieveCustomerListResponse }
     * 
     */
    public RetrieveCustomerListResponse createRetrieveCustomerListResponse() {
        return new RetrieveCustomerListResponse();
    }

    /**
     * Create an instance of {@link RetrieveMember }
     * 
     */
    public RetrieveMember createRetrieveMember() {
        return new RetrieveMember();
    }

    /**
     * Create an instance of {@link GetAicmaincInfoBySendFlagResponse }
     * 
     */
    public GetAicmaincInfoBySendFlagResponse createGetAicmaincInfoBySendFlagResponse() {
        return new GetAicmaincInfoBySendFlagResponse();
    }

    /**
     * Create an instance of {@link RetrieveOneYearActivityInfo }
     * 
     */
    public RetrieveOneYearActivityInfo createRetrieveOneYearActivityInfo() {
        return new RetrieveOneYearActivityInfo();
    }

    /**
     * Create an instance of {@link LoginForIVR }
     * 
     */
    public LoginForIVR createLoginForIVR() {
        return new LoginForIVR();
    }

    /**
     * Create an instance of {@link QueryBankSupplement }
     * 
     */
    public QueryBankSupplement createQueryBankSupplement() {
        return new QueryBankSupplement();
    }

    /**
     * Create an instance of {@link BankSupplement }
     * 
     */
    public BankSupplement createBankSupplement() {
        return new BankSupplement();
    }

    /**
     * Create an instance of {@link QueryBankAcc }
     * 
     */
    public QueryBankAcc createQueryBankAcc() {
        return new QueryBankAcc();
    }

    /**
     * Create an instance of {@link GetMemberSimpleInfoResponse }
     * 
     */
    public GetMemberSimpleInfoResponse createGetMemberSimpleInfoResponse() {
        return new GetMemberSimpleInfoResponse();
    }

    /**
     * Create an instance of {@link QueryUnderlingABOResponse }
     * 
     */
    public QueryUnderlingABOResponse createQueryUnderlingABOResponse() {
        return new QueryUnderlingABOResponse();
    }

    /**
     * Create an instance of {@link ChangeNewApplyStatusResponse }
     * 
     */
    public ChangeNewApplyStatusResponse createChangeNewApplyStatusResponse() {
        return new ChangeNewApplyStatusResponse();
    }

    /**
     * Create an instance of {@link UpdateSDISProcess }
     * 
     */
    public UpdateSDISProcess createUpdateSDISProcess() {
        return new UpdateSDISProcess();
    }

    /**
     * Create an instance of {@link SignLongContractResponse }
     * 
     */
    public SignLongContractResponse createSignLongContractResponse() {
        return new SignLongContractResponse();
    }

    /**
     * Create an instance of {@link QueryLongContractResponse }
     * 
     */
    public QueryLongContractResponse createQueryLongContractResponse() {
        return new QueryLongContractResponse();
    }

    /**
     * Create an instance of {@link RetrieveMemberList }
     * 
     */
    public RetrieveMemberList createRetrieveMemberList() {
        return new RetrieveMemberList();
    }

    /**
     * Create an instance of {@link SaveContactInfo }
     * 
     */
    public SaveContactInfo createSaveContactInfo() {
        return new SaveContactInfo();
    }

    /**
     * Create an instance of {@link RetrieveMemberChangeHisResponse }
     * 
     */
    public RetrieveMemberChangeHisResponse createRetrieveMemberChangeHisResponse() {
        return new RetrieveMemberChangeHisResponse();
    }

    /**
     * Create an instance of {@link GetAicmaincInfoBySendFlag }
     * 
     */
    public GetAicmaincInfoBySendFlag createGetAicmaincInfoBySendFlag() {
        return new GetAicmaincInfoBySendFlag();
    }

    /**
     * Create an instance of {@link CanSignLongContractResponse }
     * 
     */
    public CanSignLongContractResponse createCanSignLongContractResponse() {
        return new CanSignLongContractResponse();
    }

    /**
     * Create an instance of {@link IsNewMemberResponse }
     * 
     */
    public IsNewMemberResponse createIsNewMemberResponse() {
        return new IsNewMemberResponse();
    }

    /**
     * Create an instance of {@link QueryLongContract }
     * 
     */
    public QueryLongContract createQueryLongContract() {
        return new QueryLongContract();
    }

    /**
     * Create an instance of {@link SaveContactInfoResponse }
     * 
     */
    public SaveContactInfoResponse createSaveContactInfoResponse() {
        return new SaveContactInfoResponse();
    }

    /**
     * Create an instance of {@link ReActiveMemberForPosRenewalResponse }
     * 
     */
    public ReActiveMemberForPosRenewalResponse createReActiveMemberForPosRenewalResponse() {
        return new ReActiveMemberForPosRenewalResponse();
    }

    /**
     * Create an instance of {@link FindContactInfoResponse }
     * 
     */
    public FindContactInfoResponse createFindContactInfoResponse() {
        return new FindContactInfoResponse();
    }

    /**
     * Create an instance of {@link UpdateLongContractArchiveResponse }
     * 
     */
    public UpdateLongContractArchiveResponse createUpdateLongContractArchiveResponse() {
        return new UpdateLongContractArchiveResponse();
    }

    /**
     * Create an instance of {@link Exception }
     * 
     */
    public Exception createException() {
        return new Exception();
    }

    /**
     * Create an instance of {@link GetAicmaincInfoResponse }
     * 
     */
    public GetAicmaincInfoResponse createGetAicmaincInfoResponse() {
        return new GetAicmaincInfoResponse();
    }

    /**
     * Create an instance of {@link IfRecommendationRight }
     * 
     */
    public IfRecommendationRight createIfRecommendationRight() {
        return new IfRecommendationRight();
    }

    /**
     * Create an instance of {@link IsNewMember }
     * 
     */
    public IsNewMember createIsNewMember() {
        return new IsNewMember();
    }

    /**
     * Create an instance of {@link IsDDAndUp }
     * 
     */
    public IsDDAndUp createIsDDAndUp() {
        return new IsDDAndUp();
    }

    /**
     * Create an instance of {@link RetrieveUserBuyInfo }
     * 
     */
    public RetrieveUserBuyInfo createRetrieveUserBuyInfo() {
        return new RetrieveUserBuyInfo();
    }

    /**
     * Create an instance of {@link CanSignLongContract }
     * 
     */
    public CanSignLongContract createCanSignLongContract() {
        return new CanSignLongContract();
    }

    /**
     * Create an instance of {@link QueryLongContractByStatus }
     * 
     */
    public QueryLongContractByStatus createQueryLongContractByStatus() {
        return new QueryLongContractByStatus();
    }

    /**
     * Create an instance of {@link CustomerData }
     * 
     */
    public CustomerData createCustomerData() {
        return new CustomerData();
    }

    /**
     * Create an instance of {@link MemberByPageData }
     * 
     */
    public MemberByPageData createMemberByPageData() {
        return new MemberByPageData();
    }

    /**
     * Create an instance of {@link MemberChangeHisData }
     * 
     */
    public MemberChangeHisData createMemberChangeHisData() {
        return new MemberChangeHisData();
    }

    /**
     * Create an instance of {@link ContactInfoDTO }
     * 
     */
    public ContactInfoDTO createContactInfoDTO() {
        return new ContactInfoDTO();
    }

    /**
     * Create an instance of {@link AuditCode }
     * 
     */
    public AuditCode createAuditCode() {
        return new AuditCode();
    }

    /**
     * Create an instance of {@link Warehouse }
     * 
     */
    public Warehouse createWarehouse() {
        return new Warehouse();
    }

    /**
     * Create an instance of {@link Phone }
     * 
     */
    public Phone createPhone() {
        return new Phone();
    }

    /**
     * Create an instance of {@link OneYearActivityDO }
     * 
     */
    public OneYearActivityDO createOneYearActivityDO() {
        return new OneYearActivityDO();
    }

    /**
     * Create an instance of {@link City }
     * 
     */
    public City createCity() {
        return new City();
    }

    /**
     * Create an instance of {@link WarehouseTypeDO }
     * 
     */
    public WarehouseTypeDO createWarehouseTypeDO() {
        return new WarehouseTypeDO();
    }

    /**
     * Create an instance of {@link BlackListData }
     * 
     */
    public BlackListData createBlackListData() {
        return new BlackListData();
    }

    /**
     * Create an instance of {@link BankAcc }
     * 
     */
    public BankAcc createBankAcc() {
        return new BankAcc();
    }

    /**
     * Create an instance of {@link MemberHistoryDO }
     * 
     */
    public MemberHistoryDO createMemberHistoryDO() {
        return new MemberHistoryDO();
    }

    /**
     * Create an instance of {@link Member }
     * 
     */
    public Member createMember() {
        return new Member();
    }

    /**
     * Create an instance of {@link Email }
     * 
     */
    public Email createEmail() {
        return new Email();
    }

    /**
     * Create an instance of {@link MemberInfo }
     * 
     */
    public MemberInfo createMemberInfo() {
        return new MemberInfo();
    }

    /**
     * Create an instance of {@link Address }
     * 
     */
    public Address createAddress() {
        return new Address();
    }

    /**
     * Create an instance of {@link LoginInfoDO }
     * 
     */
    public LoginInfoDO createLoginInfoDO() {
        return new LoginInfoDO();
    }

    /**
     * Create an instance of {@link LongContractDO }
     * 
     */
    public LongContractDO createLongContractDO() {
        return new LongContractDO();
    }

    /**
     * Create an instance of {@link AicmaincBO }
     * 
     */
    public AicmaincBO createAicmaincBO() {
        return new AicmaincBO();
    }

    /**
     * Create an instance of {@link DirectDistLicence }
     * 
     */
    public DirectDistLicence createDirectDistLicence() {
        return new DirectDistLicence();
    }

    /**
     * Create an instance of {@link MemberHistory }
     * 
     */
    public MemberHistory createMemberHistory() {
        return new MemberHistory();
    }

    /**
     * Create an instance of {@link Agent }
     * 
     */
    public Agent createAgent() {
        return new Agent();
    }

    /**
     * Create an instance of {@link RecommendationSubDO }
     * 
     */
    public RecommendationSubDO createRecommendationSubDO() {
        return new RecommendationSubDO();
    }

    /**
     * Create an instance of {@link WarehouseDO }
     * 
     */
    public WarehouseDO createWarehouseDO() {
        return new WarehouseDO();
    }

    /**
     * Create an instance of {@link MemberSOData }
     * 
     */
    public MemberSOData createMemberSOData() {
        return new MemberSOData();
    }

    /**
     * Create an instance of {@link UserBuyInfoDO }
     * 
     */
    public UserBuyInfoDO createUserBuyInfoDO() {
        return new UserBuyInfoDO();
    }

    /**
     * Create an instance of {@link RecommendationDO }
     * 
     */
    public RecommendationDO createRecommendationDO() {
        return new RecommendationDO();
    }

    /**
     * Create an instance of {@link ContactInfoSO }
     * 
     */
    public ContactInfoSO createContactInfoSO() {
        return new ContactInfoSO();
    }

    /**
     * Create an instance of {@link BankSupplementDO }
     * 
     */
    public BankSupplementDO createBankSupplementDO() {
        return new BankSupplementDO();
    }

    /**
     * Create an instance of {@link Person }
     * 
     */
    public Person createPerson() {
        return new Person();
    }

    /**
     * Create an instance of {@link AicmaincDO }
     * 
     */
    public AicmaincDO createAicmaincDO() {
        return new AicmaincDO();
    }

    /**
     * Create an instance of {@link PhoneNumberDO }
     * 
     */
    public PhoneNumberDO createPhoneNumberDO() {
        return new PhoneNumberDO();
    }

    /**
     * Create an instance of {@link InquiryObject }
     * 
     */
    public InquiryObject createInquiryObject() {
        return new InquiryObject();
    }

    /**
     * Create an instance of {@link FindMemberInfoDatas }
     * 
     */
    public FindMemberInfoDatas createFindMemberInfoDatas() {
        return new FindMemberInfoDatas();
    }

    /**
     * Create an instance of {@link MemberListData }
     * 
     */
    public MemberListData createMemberListData() {
        return new MemberListData();
    }

    /**
     * Create an instance of {@link FindMemberInfoData }
     * 
     */
    public FindMemberInfoData createFindMemberInfoData() {
        return new FindMemberInfoData();
    }

    /**
     * Create an instance of {@link CustomerListData }
     * 
     */
    public CustomerListData createCustomerListData() {
        return new CustomerListData();
    }

    /**
     * Create an instance of {@link BlackListDO }
     * 
     */
    public BlackListDO createBlackListDO() {
        return new BlackListDO();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsSRInShopSale }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "isSRInShopSale")
    public JAXBElement<IsSRInShopSale> createIsSRInShopSale(IsSRInShopSale value) {
        return new JAXBElement<IsSRInShopSale>(_IsSRInShopSale_QNAME, IsSRInShopSale.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveCustomerListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "retrieveCustomerListResponse")
    public JAXBElement<RetrieveCustomerListResponse> createRetrieveCustomerListResponse(RetrieveCustomerListResponse value) {
        return new JAXBElement<RetrieveCustomerListResponse>(_RetrieveCustomerListResponse_QNAME, RetrieveCustomerListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChangeNewApplyStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "changeNewApplyStatus")
    public JAXBElement<ChangeNewApplyStatus> createChangeNewApplyStatus(ChangeNewApplyStatus value) {
        return new JAXBElement<ChangeNewApplyStatus>(_ChangeNewApplyStatus_QNAME, ChangeNewApplyStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveMember }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "retrieveMember")
    public JAXBElement<RetrieveMember> createRetrieveMember(RetrieveMember value) {
        return new JAXBElement<RetrieveMember>(_RetrieveMember_QNAME, RetrieveMember.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAicmaincInfoBySendFlagResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "getAicmaincInfoBySendFlagResponse")
    public JAXBElement<GetAicmaincInfoBySendFlagResponse> createGetAicmaincInfoBySendFlagResponse(GetAicmaincInfoBySendFlagResponse value) {
        return new JAXBElement<GetAicmaincInfoBySendFlagResponse>(_GetAicmaincInfoBySendFlagResponse_QNAME, GetAicmaincInfoBySendFlagResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveOneYearActivityInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "retrieveOneYearActivityInfo")
    public JAXBElement<RetrieveOneYearActivityInfo> createRetrieveOneYearActivityInfo(RetrieveOneYearActivityInfo value) {
        return new JAXBElement<RetrieveOneYearActivityInfo>(_RetrieveOneYearActivityInfo_QNAME, RetrieveOneYearActivityInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LoginForIVR }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "loginForIVR")
    public JAXBElement<LoginForIVR> createLoginForIVR(LoginForIVR value) {
        return new JAXBElement<LoginForIVR>(_LoginForIVR_QNAME, LoginForIVR.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryBankSupplement }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryBankSupplement")
    public JAXBElement<QueryBankSupplement> createQueryBankSupplement(QueryBankSupplement value) {
        return new JAXBElement<QueryBankSupplement>(_QueryBankSupplement_QNAME, QueryBankSupplement.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BankSupplement }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "bankSupplement")
    public JAXBElement<BankSupplement> createBankSupplement(BankSupplement value) {
        return new JAXBElement<BankSupplement>(_BankSupplement_QNAME, BankSupplement.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryBankAcc }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryBankAcc")
    public JAXBElement<QueryBankAcc> createQueryBankAcc(QueryBankAcc value) {
        return new JAXBElement<QueryBankAcc>(_QueryBankAcc_QNAME, QueryBankAcc.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChangeNewApplyStatusResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "changeNewApplyStatusResponse")
    public JAXBElement<ChangeNewApplyStatusResponse> createChangeNewApplyStatusResponse(ChangeNewApplyStatusResponse value) {
        return new JAXBElement<ChangeNewApplyStatusResponse>(_ChangeNewApplyStatusResponse_QNAME, ChangeNewApplyStatusResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateSDISProcess }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "updateSDISProcess")
    public JAXBElement<UpdateSDISProcess> createUpdateSDISProcess(UpdateSDISProcess value) {
        return new JAXBElement<UpdateSDISProcess>(_UpdateSDISProcess_QNAME, UpdateSDISProcess.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetMemberSimpleInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "getMemberSimpleInfoResponse")
    public JAXBElement<GetMemberSimpleInfoResponse> createGetMemberSimpleInfoResponse(GetMemberSimpleInfoResponse value) {
        return new JAXBElement<GetMemberSimpleInfoResponse>(_GetMemberSimpleInfoResponse_QNAME, GetMemberSimpleInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryUnderlingABOResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryUnderlingABOResponse")
    public JAXBElement<QueryUnderlingABOResponse> createQueryUnderlingABOResponse(QueryUnderlingABOResponse value) {
        return new JAXBElement<QueryUnderlingABOResponse>(_QueryUnderlingABOResponse_QNAME, QueryUnderlingABOResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SignLongContractResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "signLongContractResponse")
    public JAXBElement<SignLongContractResponse> createSignLongContractResponse(SignLongContractResponse value) {
        return new JAXBElement<SignLongContractResponse>(_SignLongContractResponse_QNAME, SignLongContractResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryLongContractResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryLongContractResponse")
    public JAXBElement<QueryLongContractResponse> createQueryLongContractResponse(QueryLongContractResponse value) {
        return new JAXBElement<QueryLongContractResponse>(_QueryLongContractResponse_QNAME, QueryLongContractResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveMemberList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "retrieveMemberList")
    public JAXBElement<RetrieveMemberList> createRetrieveMemberList(RetrieveMemberList value) {
        return new JAXBElement<RetrieveMemberList>(_RetrieveMemberList_QNAME, RetrieveMemberList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveContactInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "saveContactInfo")
    public JAXBElement<SaveContactInfo> createSaveContactInfo(SaveContactInfo value) {
        return new JAXBElement<SaveContactInfo>(_SaveContactInfo_QNAME, SaveContactInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAicmaincInfoBySendFlag }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "getAicmaincInfoBySendFlag")
    public JAXBElement<GetAicmaincInfoBySendFlag> createGetAicmaincInfoBySendFlag(GetAicmaincInfoBySendFlag value) {
        return new JAXBElement<GetAicmaincInfoBySendFlag>(_GetAicmaincInfoBySendFlag_QNAME, GetAicmaincInfoBySendFlag.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveMemberChangeHisResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "retrieveMemberChangeHisResponse")
    public JAXBElement<RetrieveMemberChangeHisResponse> createRetrieveMemberChangeHisResponse(RetrieveMemberChangeHisResponse value) {
        return new JAXBElement<RetrieveMemberChangeHisResponse>(_RetrieveMemberChangeHisResponse_QNAME, RetrieveMemberChangeHisResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CanSignLongContractResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "canSignLongContractResponse")
    public JAXBElement<CanSignLongContractResponse> createCanSignLongContractResponse(CanSignLongContractResponse value) {
        return new JAXBElement<CanSignLongContractResponse>(_CanSignLongContractResponse_QNAME, CanSignLongContractResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsNewMemberResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "isNewMemberResponse")
    public JAXBElement<IsNewMemberResponse> createIsNewMemberResponse(IsNewMemberResponse value) {
        return new JAXBElement<IsNewMemberResponse>(_IsNewMemberResponse_QNAME, IsNewMemberResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryLongContract }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryLongContract")
    public JAXBElement<QueryLongContract> createQueryLongContract(QueryLongContract value) {
        return new JAXBElement<QueryLongContract>(_QueryLongContract_QNAME, QueryLongContract.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveContactInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "saveContactInfoResponse")
    public JAXBElement<SaveContactInfoResponse> createSaveContactInfoResponse(SaveContactInfoResponse value) {
        return new JAXBElement<SaveContactInfoResponse>(_SaveContactInfoResponse_QNAME, SaveContactInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReActiveMemberForPosRenewalResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "reActiveMemberForPosRenewalResponse")
    public JAXBElement<ReActiveMemberForPosRenewalResponse> createReActiveMemberForPosRenewalResponse(ReActiveMemberForPosRenewalResponse value) {
        return new JAXBElement<ReActiveMemberForPosRenewalResponse>(_ReActiveMemberForPosRenewalResponse_QNAME, ReActiveMemberForPosRenewalResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindContactInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "findContactInfoResponse")
    public JAXBElement<FindContactInfoResponse> createFindContactInfoResponse(FindContactInfoResponse value) {
        return new JAXBElement<FindContactInfoResponse>(_FindContactInfoResponse_QNAME, FindContactInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateLongContractArchiveResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "updateLongContractArchiveResponse")
    public JAXBElement<UpdateLongContractArchiveResponse> createUpdateLongContractArchiveResponse(UpdateLongContractArchiveResponse value) {
        return new JAXBElement<UpdateLongContractArchiveResponse>(_UpdateLongContractArchiveResponse_QNAME, UpdateLongContractArchiveResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Exception }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "Exception")
    public JAXBElement<Exception> createException(Exception value) {
        return new JAXBElement<Exception>(_Exception_QNAME, Exception.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAicmaincInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "getAicmaincInfoResponse")
    public JAXBElement<GetAicmaincInfoResponse> createGetAicmaincInfoResponse(GetAicmaincInfoResponse value) {
        return new JAXBElement<GetAicmaincInfoResponse>(_GetAicmaincInfoResponse_QNAME, GetAicmaincInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IfRecommendationRight }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "ifRecommendationRight")
    public JAXBElement<IfRecommendationRight> createIfRecommendationRight(IfRecommendationRight value) {
        return new JAXBElement<IfRecommendationRight>(_IfRecommendationRight_QNAME, IfRecommendationRight.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsDDAndUp }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "isDDAndUp")
    public JAXBElement<IsDDAndUp> createIsDDAndUp(IsDDAndUp value) {
        return new JAXBElement<IsDDAndUp>(_IsDDAndUp_QNAME, IsDDAndUp.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsNewMember }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "isNewMember")
    public JAXBElement<IsNewMember> createIsNewMember(IsNewMember value) {
        return new JAXBElement<IsNewMember>(_IsNewMember_QNAME, IsNewMember.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveUserBuyInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "retrieveUserBuyInfo")
    public JAXBElement<RetrieveUserBuyInfo> createRetrieveUserBuyInfo(RetrieveUserBuyInfo value) {
        return new JAXBElement<RetrieveUserBuyInfo>(_RetrieveUserBuyInfo_QNAME, RetrieveUserBuyInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CanSignLongContract }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "canSignLongContract")
    public JAXBElement<CanSignLongContract> createCanSignLongContract(CanSignLongContract value) {
        return new JAXBElement<CanSignLongContract>(_CanSignLongContract_QNAME, CanSignLongContract.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryLongContractByStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryLongContractByStatus")
    public JAXBElement<QueryLongContractByStatus> createQueryLongContractByStatus(QueryLongContractByStatus value) {
        return new JAXBElement<QueryLongContractByStatus>(_QueryLongContractByStatus_QNAME, QueryLongContractByStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsAdaValidResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "isAdaValidResponse")
    public JAXBElement<IsAdaValidResponse> createIsAdaValidResponse(IsAdaValidResponse value) {
        return new JAXBElement<IsAdaValidResponse>(_IsAdaValidResponse_QNAME, IsAdaValidResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LoginForIVRResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "loginForIVRResponse")
    public JAXBElement<LoginForIVRResponse> createLoginForIVRResponse(LoginForIVRResponse value) {
        return new JAXBElement<LoginForIVRResponse>(_LoginForIVRResponse_QNAME, LoginForIVRResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateAicmaincSendStateResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "updateAicmaincSendStateResponse")
    public JAXBElement<UpdateAicmaincSendStateResponse> createUpdateAicmaincSendStateResponse(UpdateAicmaincSendStateResponse value) {
        return new JAXBElement<UpdateAicmaincSendStateResponse>(_UpdateAicmaincSendStateResponse_QNAME, UpdateAicmaincSendStateResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateLongContractArchive }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "updateLongContractArchive")
    public JAXBElement<UpdateLongContractArchive> createUpdateLongContractArchive(UpdateLongContractArchive value) {
        return new JAXBElement<UpdateLongContractArchive>(_UpdateLongContractArchive_QNAME, UpdateLongContractArchive.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryUnderlingABO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryUnderlingABO")
    public JAXBElement<QueryUnderlingABO> createQueryUnderlingABO(QueryUnderlingABO value) {
        return new JAXBElement<QueryUnderlingABO>(_QueryUnderlingABO_QNAME, QueryUnderlingABO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IfRecommendationRightResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "ifRecommendationRightResponse")
    public JAXBElement<IfRecommendationRightResponse> createIfRecommendationRightResponse(IfRecommendationRightResponse value) {
        return new JAXBElement<IfRecommendationRightResponse>(_IfRecommendationRightResponse_QNAME, IfRecommendationRightResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryAAInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryAAInfoResponse")
    public JAXBElement<QueryAAInfoResponse> createQueryAAInfoResponse(QueryAAInfoResponse value) {
        return new JAXBElement<QueryAAInfoResponse>(_QueryAAInfoResponse_QNAME, QueryAAInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryBankAccResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryBankAccResponse")
    public JAXBElement<QueryBankAccResponse> createQueryBankAccResponse(QueryBankAccResponse value) {
        return new JAXBElement<QueryBankAccResponse>(_QueryBankAccResponse_QNAME, QueryBankAccResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsSRInShopSaleResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "isSRInShopSaleResponse")
    public JAXBElement<IsSRInShopSaleResponse> createIsSRInShopSaleResponse(IsSRInShopSaleResponse value) {
        return new JAXBElement<IsSRInShopSaleResponse>(_IsSRInShopSaleResponse_QNAME, IsSRInShopSaleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveMemberChangeHis }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "retrieveMemberChangeHis")
    public JAXBElement<RetrieveMemberChangeHis> createRetrieveMemberChangeHis(RetrieveMemberChangeHis value) {
        return new JAXBElement<RetrieveMemberChangeHis>(_RetrieveMemberChangeHis_QNAME, RetrieveMemberChangeHis.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateAicmaincSendStateById }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "updateAicmaincSendStateById")
    public JAXBElement<UpdateAicmaincSendStateById> createUpdateAicmaincSendStateById(UpdateAicmaincSendStateById value) {
        return new JAXBElement<UpdateAicmaincSendStateById>(_UpdateAicmaincSendStateById_QNAME, UpdateAicmaincSendStateById.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindMemberInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "findMemberInfoResponse")
    public JAXBElement<FindMemberInfoResponse> createFindMemberInfoResponse(FindMemberInfoResponse value) {
        return new JAXBElement<FindMemberInfoResponse>(_FindMemberInfoResponse_QNAME, FindMemberInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateAicmaincSendStateByIdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "updateAicmaincSendStateByIdResponse")
    public JAXBElement<UpdateAicmaincSendStateByIdResponse> createUpdateAicmaincSendStateByIdResponse(UpdateAicmaincSendStateByIdResponse value) {
        return new JAXBElement<UpdateAicmaincSendStateByIdResponse>(_UpdateAicmaincSendStateByIdResponse_QNAME, UpdateAicmaincSendStateByIdResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryAAInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryAAInfo")
    public JAXBElement<QueryAAInfo> createQueryAAInfo(QueryAAInfo value) {
        return new JAXBElement<QueryAAInfo>(_QueryAAInfo_QNAME, QueryAAInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryBankSupplementByStatusResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryBankSupplementByStatusResponse")
    public JAXBElement<QueryBankSupplementByStatusResponse> createQueryBankSupplementByStatusResponse(QueryBankSupplementByStatusResponse value) {
        return new JAXBElement<QueryBankSupplementByStatusResponse>(_QueryBankSupplementByStatusResponse_QNAME, QueryBankSupplementByStatusResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveMemberResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "retrieveMemberResponse")
    public JAXBElement<RetrieveMemberResponse> createRetrieveMemberResponse(RetrieveMemberResponse value) {
        return new JAXBElement<RetrieveMemberResponse>(_RetrieveMemberResponse_QNAME, RetrieveMemberResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveMemberListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "retrieveMemberListResponse")
    public JAXBElement<RetrieveMemberListResponse> createRetrieveMemberListResponse(RetrieveMemberListResponse value) {
        return new JAXBElement<RetrieveMemberListResponse>(_RetrieveMemberListResponse_QNAME, RetrieveMemberListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetMemberContactInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "getMemberContactInfoResponse")
    public JAXBElement<GetMemberContactInfoResponse> createGetMemberContactInfoResponse(GetMemberContactInfoResponse value) {
        return new JAXBElement<GetMemberContactInfoResponse>(_GetMemberContactInfoResponse_QNAME, GetMemberContactInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsDDAndUpResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "isDDAndUpResponse")
    public JAXBElement<IsDDAndUpResponse> createIsDDAndUpResponse(IsDDAndUpResponse value) {
        return new JAXBElement<IsDDAndUpResponse>(_IsDDAndUpResponse_QNAME, IsDDAndUpResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SignLongContract }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "signLongContract")
    public JAXBElement<SignLongContract> createSignLongContract(SignLongContract value) {
        return new JAXBElement<SignLongContract>(_SignLongContract_QNAME, SignLongContract.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsSPAndUpResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "isSPAndUpResponse")
    public JAXBElement<IsSPAndUpResponse> createIsSPAndUpResponse(IsSPAndUpResponse value) {
        return new JAXBElement<IsSPAndUpResponse>(_IsSPAndUpResponse_QNAME, IsSPAndUpResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChangePasswordForIVRResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "changePasswordForIVRResponse")
    public JAXBElement<ChangePasswordForIVRResponse> createChangePasswordForIVRResponse(ChangePasswordForIVRResponse value) {
        return new JAXBElement<ChangePasswordForIVRResponse>(_ChangePasswordForIVRResponse_QNAME, ChangePasswordForIVRResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAicmaincInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "getAicmaincInfo")
    public JAXBElement<GetAicmaincInfo> createGetAicmaincInfo(GetAicmaincInfo value) {
        return new JAXBElement<GetAicmaincInfo>(_GetAicmaincInfo_QNAME, GetAicmaincInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetMemberHistoryResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "getMemberHistoryResponse")
    public JAXBElement<GetMemberHistoryResponse> createGetMemberHistoryResponse(GetMemberHistoryResponse value) {
        return new JAXBElement<GetMemberHistoryResponse>(_GetMemberHistoryResponse_QNAME, GetMemberHistoryResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveBlackListByAdas }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "retrieveBlackListByAdas")
    public JAXBElement<RetrieveBlackListByAdas> createRetrieveBlackListByAdas(RetrieveBlackListByAdas value) {
        return new JAXBElement<RetrieveBlackListByAdas>(_RetrieveBlackListByAdas_QNAME, RetrieveBlackListByAdas.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindContactInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "findContactInfo")
    public JAXBElement<FindContactInfo> createFindContactInfo(FindContactInfo value) {
        return new JAXBElement<FindContactInfo>(_FindContactInfo_QNAME, FindContactInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetMemberHistory }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "getMemberHistory")
    public JAXBElement<GetMemberHistory> createGetMemberHistory(GetMemberHistory value) {
        return new JAXBElement<GetMemberHistory>(_GetMemberHistory_QNAME, GetMemberHistory.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BankSupplementResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "bankSupplementResponse")
    public JAXBElement<BankSupplementResponse> createBankSupplementResponse(BankSupplementResponse value) {
        return new JAXBElement<BankSupplementResponse>(_BankSupplementResponse_QNAME, BankSupplementResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryRecommendationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryRecommendationResponse")
    public JAXBElement<QueryRecommendationResponse> createQueryRecommendationResponse(QueryRecommendationResponse value) {
        return new JAXBElement<QueryRecommendationResponse>(_QueryRecommendationResponse_QNAME, QueryRecommendationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsAdaValid }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "isAdaValid")
    public JAXBElement<IsAdaValid> createIsAdaValid(IsAdaValid value) {
        return new JAXBElement<IsAdaValid>(_IsAdaValid_QNAME, IsAdaValid.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryBankSupplementResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryBankSupplementResponse")
    public JAXBElement<QueryBankSupplementResponse> createQueryBankSupplementResponse(QueryBankSupplementResponse value) {
        return new JAXBElement<QueryBankSupplementResponse>(_QueryBankSupplementResponse_QNAME, QueryBankSupplementResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindMemberInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "findMemberInfo")
    public JAXBElement<FindMemberInfo> createFindMemberInfo(FindMemberInfo value) {
        return new JAXBElement<FindMemberInfo>(_FindMemberInfo_QNAME, FindMemberInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsSPAndUp }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "isSPAndUp")
    public JAXBElement<IsSPAndUp> createIsSPAndUp(IsSPAndUp value) {
        return new JAXBElement<IsSPAndUp>(_IsSPAndUp_QNAME, IsSPAndUp.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateSDISProcessResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "updateSDISProcessResponse")
    public JAXBElement<UpdateSDISProcessResponse> createUpdateSDISProcessResponse(UpdateSDISProcessResponse value) {
        return new JAXBElement<UpdateSDISProcessResponse>(_UpdateSDISProcessResponse_QNAME, UpdateSDISProcessResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReActiveMemberForPosRenewal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "reActiveMemberForPosRenewal")
    public JAXBElement<ReActiveMemberForPosRenewal> createReActiveMemberForPosRenewal(ReActiveMemberForPosRenewal value) {
        return new JAXBElement<ReActiveMemberForPosRenewal>(_ReActiveMemberForPosRenewal_QNAME, ReActiveMemberForPosRenewal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveOneYearActivityInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "retrieveOneYearActivityInfoResponse")
    public JAXBElement<RetrieveOneYearActivityInfoResponse> createRetrieveOneYearActivityInfoResponse(RetrieveOneYearActivityInfoResponse value) {
        return new JAXBElement<RetrieveOneYearActivityInfoResponse>(_RetrieveOneYearActivityInfoResponse_QNAME, RetrieveOneYearActivityInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryLongContractByStatusResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryLongContractByStatusResponse")
    public JAXBElement<QueryLongContractByStatusResponse> createQueryLongContractByStatusResponse(QueryLongContractByStatusResponse value) {
        return new JAXBElement<QueryLongContractByStatusResponse>(_QueryLongContractByStatusResponse_QNAME, QueryLongContractByStatusResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryRecommendation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryRecommendation")
    public JAXBElement<QueryRecommendation> createQueryRecommendation(QueryRecommendation value) {
        return new JAXBElement<QueryRecommendation>(_QueryRecommendation_QNAME, QueryRecommendation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveBlackListByAdasResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "retrieveBlackListByAdasResponse")
    public JAXBElement<RetrieveBlackListByAdasResponse> createRetrieveBlackListByAdasResponse(RetrieveBlackListByAdasResponse value) {
        return new JAXBElement<RetrieveBlackListByAdasResponse>(_RetrieveBlackListByAdasResponse_QNAME, RetrieveBlackListByAdasResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveUserBuyInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "retrieveUserBuyInfoResponse")
    public JAXBElement<RetrieveUserBuyInfoResponse> createRetrieveUserBuyInfoResponse(RetrieveUserBuyInfoResponse value) {
        return new JAXBElement<RetrieveUserBuyInfoResponse>(_RetrieveUserBuyInfoResponse_QNAME, RetrieveUserBuyInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetMemberSimpleInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "getMemberSimpleInfo")
    public JAXBElement<GetMemberSimpleInfo> createGetMemberSimpleInfo(GetMemberSimpleInfo value) {
        return new JAXBElement<GetMemberSimpleInfo>(_GetMemberSimpleInfo_QNAME, GetMemberSimpleInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveCustomerList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "retrieveCustomerList")
    public JAXBElement<RetrieveCustomerList> createRetrieveCustomerList(RetrieveCustomerList value) {
        return new JAXBElement<RetrieveCustomerList>(_RetrieveCustomerList_QNAME, RetrieveCustomerList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetMemberContactInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "getMemberContactInfo")
    public JAXBElement<GetMemberContactInfo> createGetMemberContactInfo(GetMemberContactInfo value) {
        return new JAXBElement<GetMemberContactInfo>(_GetMemberContactInfo_QNAME, GetMemberContactInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryBankSupplementByStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "queryBankSupplementByStatus")
    public JAXBElement<QueryBankSupplementByStatus> createQueryBankSupplementByStatus(QueryBankSupplementByStatus value) {
        return new JAXBElement<QueryBankSupplementByStatus>(_QueryBankSupplementByStatus_QNAME, QueryBankSupplementByStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChangePasswordForIVR }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "changePasswordForIVR")
    public JAXBElement<ChangePasswordForIVR> createChangePasswordForIVR(ChangePasswordForIVR value) {
        return new JAXBElement<ChangePasswordForIVR>(_ChangePasswordForIVR_QNAME, ChangePasswordForIVR.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateAicmaincSendState }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://member.facade.service.ebiz.amway.com/", name = "updateAicmaincSendState")
    public JAXBElement<UpdateAicmaincSendState> createUpdateAicmaincSendState(UpdateAicmaincSendState value) {
        return new JAXBElement<UpdateAicmaincSendState>(_UpdateAicmaincSendState_QNAME, UpdateAicmaincSendState.class, null, value);
    }

}
