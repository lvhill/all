package com.amway.atsregister.system;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * 程序启动入口
 * 
 * @author xl,xu
 * 
 */
@SpringBootApplication
@EnableSwagger2
@ComponentScan("com.amway")
// @EnableTransactionManagement
public class Swagger2SpringBoot extends SpringBootServletInitializer implements CommandLineRunner {
    Logger log = LoggerFactory.getLogger(Swagger2SpringBoot.class);

    public void run(String... arg0) throws Exception {

        log.info("runing....");
        if (arg0.length > 0 && arg0[0].equals("exitcode")) {
            throw new ExitException();
        }
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        log.info("init Swagger2");
        return application.sources(Swagger2SpringBoot.class);
    }

    public static void main(String[] args) throws Exception {
        SpringApplication.run(Swagger2SpringBoot.class, args);
    }

    class ExitException extends RuntimeException implements ExitCodeGenerator {
        private static final long serialVersionUID = 1L;

        public int getExitCode() {
            return 10;
        }

    }

    // @Bean
    // public MongoDbFactory getMongoDbFactory() {
    // MongoClient mongoClient = new
    // MongoClient("mongodb://amway:amway123@10.143.60.39:27017,10.143.60.38:27017/ServiceOutSourcing?AutoConnectRetry=true");
    // SimpleMongoDbFactory simpleMongoDbFactory = new
    // SimpleMongoDbFactory(mongoClient,"ServiceOutSourcing");
    // return simpleMongoDbFactory;
    // }

    @Bean
    public MongoTemplate getMongoTemplate(MongoDbFactory mongoDbFactory) {
        MongoTemplate mt = new MongoTemplate(mongoDbFactory);
        return mt;
    }

}
