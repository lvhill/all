package com.amway.atsregister.common.service;

import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

public interface BaseService<T> {
    /**
     * 保存或修改该对象
     * 
     * @param t
     */
    public void save(T t);

    /**
     * 保存该对象
     * 
     * @param t
     */
    public void insert(T t);

    /**
     * 根据id获取该对象
     * 
     * @param id
     * @return 查询到的对象
     */
    public T findObjectById(String id);

    /**
     * 更新对象
     * 
     * @param q
     * @return 是否成功
     */
    public void update(Query q, Update u);

    /**
     * 删除对象
     * 
     * @param q
     * @return 是否成功
     */
    public void remove(Query q);

    /**
     * 根据id判断对象是否存在
     * 
     * @param id
     * @return
     */
    public boolean isExist(String id);
}
