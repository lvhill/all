package com.amway.atsregister.aftersale.dao;

import java.util.Date;
import java.util.List;

import com.amway.atsregister.aftersale.dto.UserRegistryExt;
import com.amway.atsregister.aftersale.vo.District;
import com.amway.atsregister.common.dao.BaseDao;

public interface UserRegistryExtDao extends BaseDao<UserRegistryExt> {

	/**
	 * 查询省列表
	 * 
	 * @return
	 */
	public List<District> getProvList();

	/**
	 * 查询省的市列表
	 * 
	 * @return
	 */
	public List<District> getCitysByProvince(String provCode);

	/**
	 * 查询市的区县列表
	 * 
	 * @return
	 */
	public List<District> getTownByCity(String cityCode);

	/**
	 * 查询mongodb 某天最大的订单号
	 * 
	 * @return
	 */
	public String getMaxOrderNum(Date date);
}
