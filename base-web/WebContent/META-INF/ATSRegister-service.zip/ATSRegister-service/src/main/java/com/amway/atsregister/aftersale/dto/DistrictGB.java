package com.amway.atsregister.aftersale.dto;


import java.io.Serializable;

/**
 * 安利编码与国标编码实体类
 * 
 * @author xl,xu
 * 
 */
public class DistrictGB implements Serializable {
    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;
    private String province;
    private String district_code; // 安利区域编码
    private String district_name;// 安利区域名称
    private String par_district_id;// 上一级区域id
    private String par_district_code;// 上一级区域编码
    private String par_district_name;// 上一级区域名称
    private String district_type;// 区域类型
    private String active_flag;// 是否激活
    private String admin_code;// 国标编码
    private String update_time;// 更新时间
    private String priority_level;// 优先级别

    // 420607
    /**
     * 省份
     * 
     * @return
     */
    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    /**
     * 安利区域编码
     * 
     * @return
     */
    public String getDistrict_code() {
        return district_code;
    }

    public void setDistrict_code(String district_code) {
        this.district_code = district_code;
    }

    /**
     * 安利区域名称
     * 
     * @return
     */
    public String getDistrict_name() {
        return district_name;
    }

    public void setDistrict_name(String district_name) {
        this.district_name = district_name;
    }

    /**
     * 上一次区域id
     * 
     * @return
     */
    public String getPar_district_id() {
        return par_district_id;
    }

    public void setPar_district_id(String par_district_id) {
        this.par_district_id = par_district_id;
    }

    /**
     * 上一级区域编码
     * 
     * @return
     */
    public String getPar_district_code() {
        return par_district_code;
    }

    public void setPar_district_code(String par_district_code) {
        this.par_district_code = par_district_code;
    }

    /**
     * 上一级区域名称
     * 
     * @return
     */
    public String getPar_district_name() {
        return par_district_name;
    }

    public void setPar_district_name(String par_district_name) {
        this.par_district_name = par_district_name;
    }

    /**
     * 类型
     * 
     * @return
     */
    public String getDistrict_type() {
        return district_type;
    }

    public void setDistrict_type(String district_type) {
        this.district_type = district_type;
    }

    /**
     * 状态
     * 
     * @return
     */
    public String getActive_flag() {
        return active_flag;
    }

    public void setActive_flag(String active_flag) {
        this.active_flag = active_flag;
    }

    /**
     * 国标编码
     * 
     * @return
     */
    public String getAdmin_code() {
        return admin_code;
    }

    public void setAdmin_code(String admin_code) {
        this.admin_code = admin_code;
    }

    /**
     * 更新时间
     * 
     * @return
     */
    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    /**
     * 优先级别
     * 
     * @return
     */
    public String getPriority_level() {
        return priority_level;
    }

    public void setPriority_level(String priority_level) {
        this.priority_level = priority_level;
    }


}
