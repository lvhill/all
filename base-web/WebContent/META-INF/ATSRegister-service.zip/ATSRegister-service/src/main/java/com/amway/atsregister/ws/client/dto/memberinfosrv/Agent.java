
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>agent complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="agent">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ada" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="address" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="agtAccNam" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="agtId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="agtMth" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="agtNam" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="legalPersonNam" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="legalPersonSex" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="legalPersonSpouseNam" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="legalPersonSpouseSex" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="postCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tradeNam" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "agent", propOrder = {
    "ada",
    "address",
    "agtAccNam",
    "agtId",
    "agtMth",
    "agtNam",
    "legalPersonNam",
    "legalPersonSex",
    "legalPersonSpouseNam",
    "legalPersonSpouseSex",
    "postCde",
    "tradeNam"
})
public class Agent {

    protected Long ada;
    protected String address;
    protected String agtAccNam;
    protected Long agtId;
    protected int agtMth;
    protected String agtNam;
    protected String legalPersonNam;
    protected String legalPersonSex;
    protected String legalPersonSpouseNam;
    protected String legalPersonSpouseSex;
    protected String postCde;
    protected String tradeNam;

    /**
     * 获取ada属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAda() {
        return ada;
    }

    /**
     * 设置ada属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAda(Long value) {
        this.ada = value;
    }

    /**
     * 获取address属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress() {
        return address;
    }

    /**
     * 设置address属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress(String value) {
        this.address = value;
    }

    /**
     * 获取agtAccNam属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgtAccNam() {
        return agtAccNam;
    }

    /**
     * 设置agtAccNam属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgtAccNam(String value) {
        this.agtAccNam = value;
    }

    /**
     * 获取agtId属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAgtId() {
        return agtId;
    }

    /**
     * 设置agtId属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAgtId(Long value) {
        this.agtId = value;
    }

    /**
     * 获取agtMth属性的值。
     * 
     */
    public int getAgtMth() {
        return agtMth;
    }

    /**
     * 设置agtMth属性的值。
     * 
     */
    public void setAgtMth(int value) {
        this.agtMth = value;
    }

    /**
     * 获取agtNam属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgtNam() {
        return agtNam;
    }

    /**
     * 设置agtNam属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgtNam(String value) {
        this.agtNam = value;
    }

    /**
     * 获取legalPersonNam属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalPersonNam() {
        return legalPersonNam;
    }

    /**
     * 设置legalPersonNam属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalPersonNam(String value) {
        this.legalPersonNam = value;
    }

    /**
     * 获取legalPersonSex属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalPersonSex() {
        return legalPersonSex;
    }

    /**
     * 设置legalPersonSex属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalPersonSex(String value) {
        this.legalPersonSex = value;
    }

    /**
     * 获取legalPersonSpouseNam属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalPersonSpouseNam() {
        return legalPersonSpouseNam;
    }

    /**
     * 设置legalPersonSpouseNam属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalPersonSpouseNam(String value) {
        this.legalPersonSpouseNam = value;
    }

    /**
     * 获取legalPersonSpouseSex属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalPersonSpouseSex() {
        return legalPersonSpouseSex;
    }

    /**
     * 设置legalPersonSpouseSex属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalPersonSpouseSex(String value) {
        this.legalPersonSpouseSex = value;
    }

    /**
     * 获取postCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostCde() {
        return postCde;
    }

    /**
     * 设置postCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostCde(String value) {
        this.postCde = value;
    }

    /**
     * 获取tradeNam属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTradeNam() {
        return tradeNam;
    }

    /**
     * 设置tradeNam属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTradeNam(String value) {
        this.tradeNam = value;
    }

}
