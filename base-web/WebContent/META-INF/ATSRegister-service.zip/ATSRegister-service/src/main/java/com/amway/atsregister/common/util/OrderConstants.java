package com.amway.atsregister.common.util;

/**
 * 订单字典
 * 
 * @author xl,xu
 * 
 */
public class OrderConstants {
    // 已入库
    public final static int SAVE = 1;
    // 已推送
    public final static int PUSH = 2;
    // 待收件
    public final static int WAIT_RECEIVING = 3;
    // 待推送
    public final static int WAIT_PUSH = 4;
    // 已回传结果
    public final static int RETURN_RESULT = 5;
    // 已注销
    public final static int CANCEL = 6;
    // 重试次数
    public final static int RETRY_TIMES = 3;

    public final static String WATER_PRODUCT_SERIAL_CODE = "W001";
}
