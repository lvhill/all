
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>auditCode complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="auditCode">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="audit_Reason_Code" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="audit_Reason_Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="audit_Reason_Status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="audit_Type_Code" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="record_Change" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="update_Date" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="update_Porogram" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="user_Profile" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "auditCode", propOrder = {
    "auditReasonCode",
    "auditReasonDescription",
    "auditReasonStatus",
    "auditTypeCode",
    "recordChange",
    "updateDate",
    "updatePorogram",
    "userProfile"
})
public class AuditCode {

    @XmlElement(name = "audit_Reason_Code")
    protected String auditReasonCode;
    @XmlElement(name = "audit_Reason_Description")
    protected String auditReasonDescription;
    @XmlElement(name = "audit_Reason_Status")
    protected String auditReasonStatus;
    @XmlElement(name = "audit_Type_Code")
    protected String auditTypeCode;
    @XmlElement(name = "record_Change")
    protected String recordChange;
    @XmlElement(name = "update_Date")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar updateDate;
    @XmlElement(name = "update_Porogram")
    protected String updatePorogram;
    @XmlElement(name = "user_Profile")
    protected String userProfile;

    /**
     * 获取auditReasonCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuditReasonCode() {
        return auditReasonCode;
    }

    /**
     * 设置auditReasonCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuditReasonCode(String value) {
        this.auditReasonCode = value;
    }

    /**
     * 获取auditReasonDescription属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuditReasonDescription() {
        return auditReasonDescription;
    }

    /**
     * 设置auditReasonDescription属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuditReasonDescription(String value) {
        this.auditReasonDescription = value;
    }

    /**
     * 获取auditReasonStatus属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuditReasonStatus() {
        return auditReasonStatus;
    }

    /**
     * 设置auditReasonStatus属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuditReasonStatus(String value) {
        this.auditReasonStatus = value;
    }

    /**
     * 获取auditTypeCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuditTypeCode() {
        return auditTypeCode;
    }

    /**
     * 设置auditTypeCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuditTypeCode(String value) {
        this.auditTypeCode = value;
    }

    /**
     * 获取recordChange属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecordChange() {
        return recordChange;
    }

    /**
     * 设置recordChange属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecordChange(String value) {
        this.recordChange = value;
    }

    /**
     * 获取updateDate属性的值。
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getUpdateDate() {
        return updateDate;
    }

    /**
     * 设置updateDate属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setUpdateDate(XMLGregorianCalendar value) {
        this.updateDate = value;
    }

    /**
     * 获取updatePorogram属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdatePorogram() {
        return updatePorogram;
    }

    /**
     * 设置updatePorogram属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatePorogram(String value) {
        this.updatePorogram = value;
    }

    /**
     * 获取userProfile属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserProfile() {
        return userProfile;
    }

    /**
     * 设置userProfile属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserProfile(String value) {
        this.userProfile = value;
    }

}
