
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>oneYearActivityDO complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="oneYearActivityDO">
 *   &lt;complexContent>
 *     &lt;extension base="{http://member.facade.service.ebiz.amway.com/}inquiryObject">
 *       &lt;sequence>
 *         &lt;element name="ada" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="amplusCardLevel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="amplusPoints" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="firstRedeemDate" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="firstRedeemDateForMember" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="processDate" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="redeemQuatity" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "oneYearActivityDO", propOrder = {
    "ada",
    "amplusCardLevel",
    "amplusPoints",
    "firstRedeemDate",
    "firstRedeemDateForMember",
    "processDate",
    "redeemQuatity"
})
public class OneYearActivityDO
    extends InquiryObject
{

    protected Long ada;
    protected String amplusCardLevel;
    protected Double amplusPoints;
    protected Integer firstRedeemDate;
    protected Integer firstRedeemDateForMember;
    protected Integer processDate;
    protected Long redeemQuatity;

    /**
     * 获取ada属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAda() {
        return ada;
    }

    /**
     * 设置ada属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAda(Long value) {
        this.ada = value;
    }

    /**
     * 获取amplusCardLevel属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmplusCardLevel() {
        return amplusCardLevel;
    }

    /**
     * 设置amplusCardLevel属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmplusCardLevel(String value) {
        this.amplusCardLevel = value;
    }

    /**
     * 获取amplusPoints属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getAmplusPoints() {
        return amplusPoints;
    }

    /**
     * 设置amplusPoints属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setAmplusPoints(Double value) {
        this.amplusPoints = value;
    }

    /**
     * 获取firstRedeemDate属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getFirstRedeemDate() {
        return firstRedeemDate;
    }

    /**
     * 设置firstRedeemDate属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setFirstRedeemDate(Integer value) {
        this.firstRedeemDate = value;
    }

    /**
     * 获取firstRedeemDateForMember属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getFirstRedeemDateForMember() {
        return firstRedeemDateForMember;
    }

    /**
     * 设置firstRedeemDateForMember属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setFirstRedeemDateForMember(Integer value) {
        this.firstRedeemDateForMember = value;
    }

    /**
     * 获取processDate属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getProcessDate() {
        return processDate;
    }

    /**
     * 设置processDate属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setProcessDate(Integer value) {
        this.processDate = value;
    }

    /**
     * 获取redeemQuatity属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getRedeemQuatity() {
        return redeemQuatity;
    }

    /**
     * 设置redeemQuatity属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setRedeemQuatity(Long value) {
        this.redeemQuatity = value;
    }

}
