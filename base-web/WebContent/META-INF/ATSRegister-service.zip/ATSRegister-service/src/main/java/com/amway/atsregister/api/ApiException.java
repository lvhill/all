package com.amway.atsregister.api;

// @javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date =
// "2017-02-16T16:42:18.560+08:00")
public class ApiException extends Exception {
    private int code;

    public ApiException(int code, String msg) {
        super(msg);
        this.code = code;
    }
}
