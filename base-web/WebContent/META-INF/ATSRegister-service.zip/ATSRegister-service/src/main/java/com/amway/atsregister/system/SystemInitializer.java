package com.amway.atsregister.system;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.amway.atsregister.aftersale.service.AftersaleService;
import com.amway.atsregister.aftersale.vo.UserRegistryVO;
import com.amway.atsregister.common.util.SpringContextUtil;
import com.amway.atsregister.hazelcast.MyHazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IQueue;

/**
 * 获取spring上下文
 * 
 * @author issuser
 * 
 */
@Component
public class SystemInitializer implements ApplicationListener<ApplicationEvent> {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ApplicationContext ctx;

	public void onApplicationEvent(ApplicationEvent event) {
		if (ContextRefreshedEvent.class.isInstance(event) && event.getSource().toString().contains("startup date")) {
			logger.info("---System is initializaing... ---");
			initSpringContextUtil();
			new Thread(new AftersaleRunnable()).start();

		}
	}

	private void initSpringContextUtil() {
		SpringContextUtil.setApplicationContext(ctx);
	}

	class AftersaleRunnable implements Runnable {
		private final Logger logger = LoggerFactory.getLogger(this.getClass());
		private UserRegistryVO serRegistryVO = null;

		@Override
		public void run() {
			while (true) {
				try {
					HazelcastInstance instance = MyHazelcast.getHazelcastInstance();
					IQueue<UserRegistryVO> queue = instance.getQueue("UserRegistryVO_QUEUE");
					serRegistryVO = queue.poll(1000, TimeUnit.MILLISECONDS);
					if (null == serRegistryVO) {
						Thread.sleep(1000 * 5);
						logger.info("  AftersaleRunnable sleep  1 SECONDS  ! ");
					} else {
						AftersaleService a = (AftersaleService) SpringContextUtil.getBean("aftersaleService");
						a.save(serRegistryVO);
					}
				} catch (Exception e) {
					logger.error("AftersaleRunnable exception!", e);
				}
			}
		}

	}

}
