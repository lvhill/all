
package com.amway.atsregister.ws.client.dto.memberinfosrv;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>directDistLicence complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="directDistLicence">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ada" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="areaNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="brchCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="brhNam" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="directReg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="distId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="distName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="distSex" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="distVocationCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="distVocationDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="licenceEffDte" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="licenceId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="licenceNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="processDate" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="processTime" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="regNam" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rsvdc1" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="rsvdc2" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="rsvdc3" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="rsvdc4" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="rsvst1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rsvst2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rsvst3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rsvst4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="shopCde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="spouseNam" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="spouseSex" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="telephone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "directDistLicence", propOrder = {
    "ada",
    "areaNo",
    "brchCde",
    "brhNam",
    "directReg",
    "distId",
    "distName",
    "distSex",
    "distVocationCde",
    "distVocationDesc",
    "licenceEffDte",
    "licenceId",
    "licenceNum",
    "processDate",
    "processTime",
    "regNam",
    "rsvdc1",
    "rsvdc2",
    "rsvdc3",
    "rsvdc4",
    "rsvst1",
    "rsvst2",
    "rsvst3",
    "rsvst4",
    "shopCde",
    "spouseNam",
    "spouseSex",
    "status",
    "telephone"
})
public class DirectDistLicence {

    protected Long ada;
    protected String areaNo;
    protected String brchCde;
    protected String brhNam;
    protected String directReg;
    protected String distId;
    protected String distName;
    protected String distSex;
    protected String distVocationCde;
    protected String distVocationDesc;
    protected Long licenceEffDte;
    protected Long licenceId;
    protected String licenceNum;
    protected Long processDate;
    protected Long processTime;
    protected String regNam;
    protected long rsvdc1;
    protected long rsvdc2;
    protected long rsvdc3;
    protected long rsvdc4;
    protected String rsvst1;
    protected String rsvst2;
    protected String rsvst3;
    protected String rsvst4;
    protected String shopCde;
    protected String spouseNam;
    protected String spouseSex;
    protected String status;
    protected String telephone;

    /**
     * 获取ada属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAda() {
        return ada;
    }

    /**
     * 设置ada属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAda(Long value) {
        this.ada = value;
    }

    /**
     * 获取areaNo属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAreaNo() {
        return areaNo;
    }

    /**
     * 设置areaNo属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAreaNo(String value) {
        this.areaNo = value;
    }

    /**
     * 获取brchCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBrchCde() {
        return brchCde;
    }

    /**
     * 设置brchCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrchCde(String value) {
        this.brchCde = value;
    }

    /**
     * 获取brhNam属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBrhNam() {
        return brhNam;
    }

    /**
     * 设置brhNam属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrhNam(String value) {
        this.brhNam = value;
    }

    /**
     * 获取directReg属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDirectReg() {
        return directReg;
    }

    /**
     * 设置directReg属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDirectReg(String value) {
        this.directReg = value;
    }

    /**
     * 获取distId属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistId() {
        return distId;
    }

    /**
     * 设置distId属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistId(String value) {
        this.distId = value;
    }

    /**
     * 获取distName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistName() {
        return distName;
    }

    /**
     * 设置distName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistName(String value) {
        this.distName = value;
    }

    /**
     * 获取distSex属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistSex() {
        return distSex;
    }

    /**
     * 设置distSex属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistSex(String value) {
        this.distSex = value;
    }

    /**
     * 获取distVocationCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistVocationCde() {
        return distVocationCde;
    }

    /**
     * 设置distVocationCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistVocationCde(String value) {
        this.distVocationCde = value;
    }

    /**
     * 获取distVocationDesc属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistVocationDesc() {
        return distVocationDesc;
    }

    /**
     * 设置distVocationDesc属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistVocationDesc(String value) {
        this.distVocationDesc = value;
    }

    /**
     * 获取licenceEffDte属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLicenceEffDte() {
        return licenceEffDte;
    }

    /**
     * 设置licenceEffDte属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLicenceEffDte(Long value) {
        this.licenceEffDte = value;
    }

    /**
     * 获取licenceId属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLicenceId() {
        return licenceId;
    }

    /**
     * 设置licenceId属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLicenceId(Long value) {
        this.licenceId = value;
    }

    /**
     * 获取licenceNum属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLicenceNum() {
        return licenceNum;
    }

    /**
     * 设置licenceNum属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLicenceNum(String value) {
        this.licenceNum = value;
    }

    /**
     * 获取processDate属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getProcessDate() {
        return processDate;
    }

    /**
     * 设置processDate属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setProcessDate(Long value) {
        this.processDate = value;
    }

    /**
     * 获取processTime属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getProcessTime() {
        return processTime;
    }

    /**
     * 设置processTime属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setProcessTime(Long value) {
        this.processTime = value;
    }

    /**
     * 获取regNam属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegNam() {
        return regNam;
    }

    /**
     * 设置regNam属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegNam(String value) {
        this.regNam = value;
    }

    /**
     * 获取rsvdc1属性的值。
     * 
     */
    public long getRsvdc1() {
        return rsvdc1;
    }

    /**
     * 设置rsvdc1属性的值。
     * 
     */
    public void setRsvdc1(long value) {
        this.rsvdc1 = value;
    }

    /**
     * 获取rsvdc2属性的值。
     * 
     */
    public long getRsvdc2() {
        return rsvdc2;
    }

    /**
     * 设置rsvdc2属性的值。
     * 
     */
    public void setRsvdc2(long value) {
        this.rsvdc2 = value;
    }

    /**
     * 获取rsvdc3属性的值。
     * 
     */
    public long getRsvdc3() {
        return rsvdc3;
    }

    /**
     * 设置rsvdc3属性的值。
     * 
     */
    public void setRsvdc3(long value) {
        this.rsvdc3 = value;
    }

    /**
     * 获取rsvdc4属性的值。
     * 
     */
    public long getRsvdc4() {
        return rsvdc4;
    }

    /**
     * 设置rsvdc4属性的值。
     * 
     */
    public void setRsvdc4(long value) {
        this.rsvdc4 = value;
    }

    /**
     * 获取rsvst1属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRsvst1() {
        return rsvst1;
    }

    /**
     * 设置rsvst1属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRsvst1(String value) {
        this.rsvst1 = value;
    }

    /**
     * 获取rsvst2属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRsvst2() {
        return rsvst2;
    }

    /**
     * 设置rsvst2属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRsvst2(String value) {
        this.rsvst2 = value;
    }

    /**
     * 获取rsvst3属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRsvst3() {
        return rsvst3;
    }

    /**
     * 设置rsvst3属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRsvst3(String value) {
        this.rsvst3 = value;
    }

    /**
     * 获取rsvst4属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRsvst4() {
        return rsvst4;
    }

    /**
     * 设置rsvst4属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRsvst4(String value) {
        this.rsvst4 = value;
    }

    /**
     * 获取shopCde属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShopCde() {
        return shopCde;
    }

    /**
     * 设置shopCde属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShopCde(String value) {
        this.shopCde = value;
    }

    /**
     * 获取spouseNam属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpouseNam() {
        return spouseNam;
    }

    /**
     * 设置spouseNam属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpouseNam(String value) {
        this.spouseNam = value;
    }

    /**
     * 获取spouseSex属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpouseSex() {
        return spouseSex;
    }

    /**
     * 设置spouseSex属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpouseSex(String value) {
        this.spouseSex = value;
    }

    /**
     * 获取status属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 设置status属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * 获取telephone属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTelephone() {
        return telephone;
    }

    /**
     * 设置telephone属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTelephone(String value) {
        this.telephone = value;
    }

}
