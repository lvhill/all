package com.amway.atsregister.aftersale.service;

import java.util.List;

public interface OrderNumService {

	/**
	 * 取到多个连续有效的工单号
	 * 
	 * @param size
	 *            工单号数量
	 * @return
	 */
	public List<String> getNextOrderNum(int size) throws Exception;

}
