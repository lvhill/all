/*
 * To change this license header, choose License Headers in Project Properties. To change this
 * template file, choose Tools | Templates and open the template in the editor.
 */
package com.amway.atsregister.common.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 安全时间format类
 * 
 * @author xl,xu
 * 
 */
public class SafeDateFormat {
    final static String DEFAULFORMAT = "yyyy-MM-dd";
    final static Map<String, ThreadLocal<DateFormat>> threadLocalPool = new HashMap<String, ThreadLocal<DateFormat>>();
    final static ThreadLocal<DateFormat> DefaultThreadLocal = new ThreadLocal<DateFormat>() {
        @Override
        protected synchronized DateFormat initialValue() {
            return new SimpleDateFormat(DEFAULFORMAT);
        }
    };

    static {
        threadLocalPool.put(DEFAULFORMAT, DefaultThreadLocal);
    }

    public static Date parse(String dateStr) throws ParseException {

        return DefaultThreadLocal.get().parse(dateStr);

    }

    public static Date parse(final String format, String dateStr) throws ParseException {
        ThreadLocal<DateFormat> threadLocal = threadLocalPool.get(format);
        if (threadLocal == null) {
            threadLocal = new ThreadLocal<DateFormat>() {
                @Override
                protected synchronized DateFormat initialValue() {
                    return new SimpleDateFormat(format);
                }
            };
            threadLocalPool.put(format, threadLocal);
        }
        return threadLocal.get().parse(dateStr);

    }

    public static String format(Date date) {
        return DefaultThreadLocal.get().format(date);
    }

    public static String format(final String format, Date date) {
        ThreadLocal<DateFormat> threadLocal = threadLocalPool.get(format);
        if (threadLocal == null) {
            threadLocal = new ThreadLocal<DateFormat>() {
                @Override
                protected synchronized DateFormat initialValue() {
                    return new SimpleDateFormat(format);
                }
            };
            threadLocalPool.put(format, threadLocal);
        }
        return threadLocal.get().format(date);
    }
}
